# Menjalankan E-SURAT dengan file BAT

## Bisa langsung dengan satu kali membuka file?

**Ya, untuk pemakaian harian setelah setup awal selesai.** Tidak perlu mengetik perintah: cukup klik dua kali `jalankan-esurat.bat`, lalu tunggu browser terbuka otomatis.

Pada pemakaian pertama, peluncur memasang dependensi dan membangun aplikasi. Pemakaian berikutnya memakai build yang masih sesuai, sehingga tidak selalu membangun ulang. Jika kode, aset, konfigurasi, atau dependensi berubah, mode bawaan memvalidasi dan membangun ulang otomatis.

**Belum bisa langsung berjalan di komputer kosong tanpa persiapan.** Node.js, PostgreSQL, database, dan konfigurasi koneksinya harus disiapkan satu kali. File BAT bukan installer portable, tidak memasang PostgreSQL/Node.js secara otomatis, dan tetap membutuhkan seluruh proyek.

## File utama

**`jalankan-esurat.bat`** berada di folder utama proyek. Salinan unduhan tersedia pada `/unduhan/jalankan-esurat.bat`.

File BAT memerlukan **seluruh proyek E-SURAT**, termasuk folder `src`, `scripts`, `drizzle`, `public`, `package.json`, dan lockfile. Mengunduh file BAT saja tidak mengunduh aplikasi lengkap.

## Persiapan pertama — cukup sekali

1. Pasang **Node.js 22 LTS atau lebih baru**, termasuk npm, dari https://nodejs.org/. Tutup dan buka kembali terminal setelah pemasangan.
2. Pasang dan aktifkan **PostgreSQL**. Buat database kosong bernama `esurat_db` melalui pgAdmin, dengan pemilik/pengguna database yang sesuai. File BAT tidak memasang PostgreSQL atau membuat database/server secara otomatis.
3. Ekstrak seluruh proyek ke folder lokal, misalnya `C:\Aplikasi\E-SURAT`. Folder dengan spasi juga didukung.
4. Jika belum mempunyai `.env`, salin `.env.windows.example` menjadi `.env`. Ganti placeholder password dan alamat pada `DATABASE_URL` sesuai PostgreSQL Anda. Karakter khusus pada password harus di-URL-encode.
5. Letakkan `jalankan-esurat.bat` sejajar dengan `package.json`, lalu **klik dua kali**. Internet diperlukan untuk pemasangan dependensi pertama.

Jika `.env` belum ada dan `DATABASE_URL` belum tersedia, peluncur membuat contoh `.env` tanpa menimpa konfigurasi yang sudah ada, lalu berhenti dengan petunjuk pengisian. Jalankan ulang setelah konfigurasi dilengkapi. Konfigurasi `.env.local` dan file lingkungan mode pengembangan/produksi juga didukung dengan prioritas yang mengikuti Next.js; variabel lingkungan sistem memiliki prioritas tertinggi.

## Pemakaian harian

1. Pastikan layanan PostgreSQL aktif.
2. Klik dua kali **`jalankan-esurat.bat`**.
3. Tunggu pesan **E-SURAT siap**, lalu browser membuka `http://localhost:3000` atau port pengganti.

**Biarkan terminal tetap terbuka. Tekan Ctrl+C untuk menghentikan proses aplikasi milik peluncur.** Aplikasi lain yang memakai port yang sama tidak dimatikan; peluncur mencoba hingga sembilan port berikutnya.

## Yang dilakukan peluncur

- Memeriksa Node.js, npm, dan konfigurasi koneksi database tanpa menampilkan password.
- Memasang dependensi menggunakan lockfile pada pemasangan pertama atau saat dependensi/platform berubah.
- Memeriksa PostgreSQL melalui Drizzle ORM.
- Menerapkan migrasi pada database kosong. Skema lengkap yang sudah ada dipertahankan; skema tidak lengkap/tidak dikenal tanpa riwayat migrasi ditolak tanpa dihapus atau ditimpa.
- Menghitung fingerprint sumber, aset, konfigurasi, dan variabel publik untuk menentukan apakah build masih sesuai.
- Memvalidasi route dan TypeScript, lalu membangun aplikasi jika diperlukan. Pemasangan dependensi baru selalu memicu build produksi baru, termasuk ketika memakai mode cepat.
- Menjalankan server yang hanya mendengarkan koneksi lokal.
- Menunggu healthcheck berhasil, lalu membuka browser secara otomatis.

Catatan build disimpan pada `.next/esurat-launcher-build.json`; tidak berisi password atau isi konfigurasi, hanya fingerprint dan identitas build. Jika catatan hilang/rusak, atau identitas build berbeda, mode bawaan membangun ulang agar aman.

## Mode tambahan

Jalankan dari Command Prompt pada folder proyek:

- `jalankan-esurat.bat` — mode otomatis yang disarankan; build pertama atau saat perubahan terdeteksi, lalu jalankan.
- `jalankan-esurat.bat --build-ulang` — paksa validasi dan build ulang untuk pemecahan masalah.
- `jalankan-esurat.bat --cepat` — gunakan build yang tersedia tanpa mengecek perubahan kode. Jika build belum ada atau dependensi baru dipasang, build tetap dibuat. Mode bawaan lebih disarankan untuk pemakaian harian.
- `jalankan-esurat.bat --dev` — mode pengembangan dengan pemuatan ulang perubahan kode.
- `jalankan-esurat.bat --periksa` — periksa konfigurasi, dependensi yang sudah terpasang, dan database; tidak menjalankan server atau mengubah skema.
- `jalankan-esurat.bat --tanpa-browser` — jalankan tanpa membuka browser otomatis; dapat digabung dengan salah satu mode di atas.
- `jalankan-esurat.bat --help` — tampilkan bantuan.

Ubah `PORT` pada konfigurasi jika ingin menggunakan port tertentu. Jika menjalankan salinan BAT dari folder lain, peluncur dapat meminta lokasi folder proyek lengkap.

## Akses workspace demo

Jika `DEMO_MODE=true`, workspace demo dibuat oleh aplikasi pada akses pertama. Akun Super Admin demo: **admin@esurat.id**, kata sandi **ESurat!2026**. Data dan perubahan tetap disimpan di PostgreSQL.

Jangan menyimpan dokumen nyata di workspace demo. Untuk workspace baru non-demo, gunakan database baru/kosong, set `DEMO_MODE=false`, lalu isi `ADMIN_EMAIL` dan `ADMIN_PASSWORD` minimal 12 karakter sebelum akses pertama. Tidak ada password produksi yang ditentukan oleh file BAT.

## Penyelesaian masalah

- **Node.js/npm tidak ditemukan:** perbaiki instalasi dan PATH, kemudian buka kembali terminal.
- **Database tidak bisa dihubungi:** pastikan layanan PostgreSQL berjalan; periksa host dan port pada `DATABASE_URL`.
- **Database belum dibuat:** buat database melalui pgAdmin terlebih dahulu.
- **Login PostgreSQL gagal:** periksa pengguna, password, dan encoding URL pada password.
- **Skema tidak lengkap:** jangan menghapus data untuk mencoba ulang; backup database dan periksa migrasi dengan administrator.
- **Build gagal:** baca pesan yang tetap terlihat pada terminal. Pastikan proyek lengkap dan koneksi internet tersedia saat pemasangan dependensi.
- **Browser tidak terbuka:** buka alamat yang tercetak pada terminal secara manual.
- **Perubahan kode tidak terlihat:** gunakan mode bawaan atau `--build-ulang`, bukan `--cepat`.

Peluncur ini untuk pemakaian lokal Windows, bukan layanan Windows otomatis atau konfigurasi hosting publik. Deployment publik tetap membutuhkan HTTPS, pengelolaan proses, akses database terbatas, dan backup yang sesuai. Detail aplikasi terdapat pada `README.md`.
