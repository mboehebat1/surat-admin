import assert from 'node:assert/strict';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import { PDFDocument } from 'pdf-lib';
import PizZip from 'pizzip';

const base = process.env.TEST_BASE_URL || 'http://127.0.0.1:3000';
const password = process.env.TEST_DEMO_PASSWORD || 'ESurat!2026';
let checks = 0;
function pass(message) { checks++; console.log(`✓ ${message}`); }
async function request(cookie, path, { method = 'GET', body, status = 200, binary = false } = {}) {
  const headers = { ...(cookie ? { cookie } : {}), ...(method !== 'GET' ? { origin: base } : {}) };
  if (body && !(body instanceof FormData)) headers['content-type'] = 'application/json';
  const response = await fetch(`${base}/api/${path}`, { method, headers, body: body instanceof FormData ? body : body ? JSON.stringify(body) : undefined });
  if (binary && response.status === status) return Buffer.from(await response.arrayBuffer());
  const result = await response.json();
  assert.equal(response.status, status, `${method} ${path}: ${JSON.stringify(result)}`);
  return result;
}
async function login(email) {
  const response = await fetch(`${base}/api/auth`, { method: 'POST', headers: { 'content-type': 'application/json', origin: base }, body: JSON.stringify({ action: 'login', email, password }) });
  assert.equal(response.status, 200, `Login failed for ${email}: ${await response.text()}`);
  const cookie = response.headers.get('set-cookie')?.split(';')[0]; assert.ok(cookie); return cookie;
}

await request(null, 'workspace', { status: 401 }); pass('Endpoint privat menolak sesi kosong');
const accounts = {};
for (const name of ['admin', 'siti', 'dimas', 'rina', 'budi', 'hendra']) accounts[name] = await login(`${name}@esurat.id`);
pass('Autentikasi berfungsi pada seluruh role');
const workspace = await request(accounts.admin, 'workspace'); assert.ok(workspace.letters.length); assert.equal(workspace.user.roleId, 'super_admin'); assert.ok(!JSON.stringify(workspace).includes('passwordHash')); pass('Workspace membaca PostgreSQL tanpa membocorkan hash password');
const wf = workspace.workflows.find(w => w.active && w.steps.length === 3); assert.ok(wf);

const doc = new Document({ sections: [{ children: [
  new Paragraph('NUSANTARA DIGITAL INDONESIA'), new Paragraph('Sekretariat Kantor Pusat'), new Paragraph('Jakarta'), new Paragraph(''), new Paragraph('SURAT KOORDINASI INTERNAL'), new Paragraph('Nomor: {{nomor_surat}}'), new Paragraph('Tanggal: {{tanggal_surat}}'), new Paragraph('Perihal: {{perihal}}'), new Paragraph(''), new Paragraph({ children: [new TextRun('Yth. {{nama_'), new TextRun({ text: 'penerima}}', bold: true })] }), new Paragraph(''), new Paragraph('Dengan hormat,'), new Paragraph('{{isi_surat}}'), new Paragraph('Terima kasih atas perhatian dan kerja sama Bapak/Ibu.'),
] }] });
const docBuffer = await Packer.toBuffer(doc);
const file = new File([docBuffer], 'Surat-Koordinasi.docx', { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
const inspectForm = new FormData(); inspectForm.set('file', file);
const inspection = await request(accounts.admin, 'template-inspect', { method: 'POST', body: inspectForm });
assert.equal(inspection.fields.length, 5); assert.ok(inspection.fields.some(f => f.key === 'nama_penerima')); pass('Placeholder DOCX lintas text run terdeteksi otomatis');
const badForm = new FormData(); badForm.set('file', new File(['not a zip'], 'rusak.docx', { type: file.type })); await request(accounts.admin, 'template-inspect', { method: 'POST', body: badForm, status: 400 }); pass('DOCX tidak valid ditolak dengan error terstruktur');
const pdf = await PDFDocument.create(); pdf.addPage().drawText('Agenda Rapat Strategi Semester'); const pdfBytes = await pdf.save();
const templateForm = new FormData(); templateForm.set('name', 'Surat Koordinasi Internal'); templateForm.set('category', 'Undangan'); templateForm.set('description', 'Koordinasi antarbagian dan agenda rapat strategis.'); templateForm.set('workflowId', wf.id); templateForm.set('file', file); templateForm.set('reference', new File([pdfBytes], 'Referensi.pdf', { type: 'application/pdf' }));
const template = await request(accounts.admin, 'templates', { method: 'POST', body: templateForm, status: 201 });
const reference = await request(accounts.siti, `templates/${template.id}/download?format=reference`, { binary: true }); assert.equal(reference.subarray(0, 5).toString(), '%PDF-'); pass('Template dan PDF referensi tersimpan serta dapat diakses secara privat');
const data = { tanggal_surat: new Date().toISOString().slice(0, 10), perihal: 'Undangan Rapat Strategi Semester', nama_penerima: 'Para Kepala Bagian', isi_surat: 'Dalam rangka penyusunan program kerja semester, kami mengundang Bapak/Ibu untuk menghadiri rapat koordinasi strategis di ruang rapat utama.\n\nMohon menyiapkan laporan capaian kerja dan rencana kegiatan masing-masing bagian.' };
const payload = { title: 'Undangan Rapat Strategi Semester', templateId: template.id, direction: 'keluar', data, intent: 'draft' };
let letter = await request(accounts.siti, 'letters', { method: 'POST', body: payload, status: 201 }); assert.equal(letter.status, 'draft'); const id = letter.id;
await request(accounts.dimas, `letters/${id}`, { status: 403 }); pass('Draft persisten dan pembatasan akses antar-pembuat berfungsi');
const attachmentForm = new FormData(); attachmentForm.set('file', new File([pdfBytes], 'Agenda-Rapat.pdf', { type: 'application/pdf' })); const attachment = await request(accounts.siti, `letters/${id}/attachments`, { method: 'POST', body: attachmentForm, status: 201 }); assert.ok(attachment.id);
const attachmentBytes = await request(accounts.siti, `attachments/${attachment.id}`, { binary: true }); assert.equal(attachmentBytes.subarray(0, 5).toString(), '%PDF-'); pass('Lampiran tervalidasi, persisten dan dapat diunduh');
letter = await request(accounts.siti, `letters/${id}`, { method: 'PATCH', body: { ...payload, intent: 'submit' } }); assert.equal(letter.status, 'pending_review');
await request(accounts.siti, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 0 }, status: 403 });
await request(accounts.hendra, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 0 }, status: 403 }); pass('Persetujuan sendiri dan pelompatan kewenangan ditolak');
letter = await request(accounts.rina, `letters/${id}/action`, { method: 'POST', body: { action: 'start_review', expectedStep: 0 } }); assert.equal(letter.status, 'reviewing');
letter = await request(accounts.rina, `letters/${id}/action`, { method: 'POST', body: { action: 'revision', expectedStep: 0, note: 'Mohon melengkapi waktu pelaksanaan dan agenda rapat.' } }); assert.equal(letter.status, 'revision');
let detail = await request(accounts.siti, `letters/${id}`); assert.equal(detail.revisions.length, 1); assert.ok(detail.approvals.length >= 3);
const revisedData = { ...data, isi_surat: `${data.isi_surat}\n\nPelaksanaan: Kamis, pukul 09.00 WIB. Agenda: evaluasi capaian dan penetapan target semester.` };
letter = await request(accounts.siti, `letters/${id}`, { method: 'PATCH', body: { ...payload, data: revisedData, intent: 'submit' } }); assert.equal(letter.revision, 2); assert.equal(letter.currentStep, 0); pass('Revisi dan pengajuan ulang mempertahankan riwayat serta lampiran');
letter = await request(accounts.rina, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 0, note: 'Administrasi lengkap.' } }); assert.equal(letter.currentStep, 1);
await request(accounts.admin, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 0 }, status: 409 }); pass('Aksi kedaluwarsa ditolak tanpa memajukan workflow');
letter = await request(accounts.budi, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 1, note: 'Isi dan agenda telah diverifikasi.' } }); assert.equal(letter.status, 'pending_approval'); assert.equal(letter.currentStep, 2);
letter = await request(accounts.hendra, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 2, note: 'Disetujui untuk pelaksanaan.' } }); assert.equal(letter.status, 'approved'); assert.ok(letter.number); assert.ok(letter.approvedAt); pass(`Workflow bertingkat dan nomor otomatis berhasil: ${letter.number}`);
await request(accounts.hendra, `letters/${id}/action`, { method: 'POST', body: { action: 'approve', expectedStep: 2 }, status: 409 });
await request(accounts.siti, `letters/${id}`, { method: 'PATCH', body: payload, status: 409 }); await request(accounts.dimas, `letters/${id}/download?format=pdf`, { status: 403 }); pass('Surat final tidak dapat diedit, disetujui ulang, atau diunduh tanpa akses');
const pdfDownload = await request(accounts.siti, `letters/${id}/download?format=pdf`, { binary: true }); assert.equal(pdfDownload.subarray(0, 5).toString(), '%PDF-'); await PDFDocument.load(pdfDownload);
const docxDownload = await request(accounts.siti, `letters/${id}/download?format=docx`, { binary: true }); const exportedXml = new PizZip(docxDownload).file('word/document.xml').asText(); assert.ok(exportedXml.includes('Para Kepala Bagian')); assert.ok(!exportedXml.includes('{{')); pass('Ekspor PDF dan DOCX menghasilkan dokumen valid dengan field terisi');
await request(accounts.admin, `templates/${template.id}`, { method: 'PATCH', body: { content: 'TEMPLATE VERSI BERUBAH\n\n{{perihal}}\n{{isi_surat}}' } }); detail = await request(accounts.siti, `letters/${id}`); assert.ok(detail.documentContent.includes('SURAT KOORDINASI INTERNAL')); assert.ok(!detail.documentContent.includes('TEMPLATE VERSI BERUBAH')); pass('Snapshot arsip tetap utuh setelah template diubah');
await request(accounts.rina, `letters/${id}/action`, { method: 'POST', body: { action: 'distribute', note: 'Sekretariat dan seluruh Kepala Bagian' } }); letter = await request(accounts.rina, `letters/${id}/action`, { method: 'POST', body: { action: 'archive' } }); assert.equal(letter.status, 'archived'); pass('Distribusi internal dan pengarsipan mengubah status secara sah');
const creatorWorkspace = await request(accounts.siti, 'workspace'); const notification = creatorWorkspace.notifications.find(n => n.letterId === id && !n.read); assert.ok(notification); await request(accounts.siti, 'notifications', { method: 'POST', body: { id: notification.id } }); pass('Notifikasi otomatis dan penandaan dibaca berfungsi');
const report = await request(accounts.admin, 'reports?format=xlsx', { binary: true }); const sheet = new PizZip(report).file('xl/worksheets/sheet1.xml').asText(); assert.ok(sheet.includes(payload.title)); assert.ok(sheet.includes('inlineStr')); const reportPdf = await request(accounts.admin, 'reports?format=pdf', { binary: true }); await PDFDocument.load(reportPdf); pass('Laporan Excel OOXML dan PDF valid berdasarkan data aktual');
await request(accounts.siti, 'users', { method: 'POST', body: {}, status: 403 }); await request(accounts.siti, 'backup', { status: 403 }); pass('Manajemen akun dan backup tidak dapat diakses pengguna biasa');
const backup = await request(accounts.admin, 'backup'); assert.ok(backup.letterAttachments.some(a => a.id === attachment.id)); assert.ok(backup.letterArchives.some(a => a.letterId === id)); assert.ok(backup.auditLogs.some(a => a.objectId === id && a.action === 'approve')); pass('Backup memuat dokumen, relasi, arsip dan audit persetujuan');
await request(accounts.admin, `templates/${template.id}`, { method: 'DELETE' }); const finalWorkspace = await request(accounts.admin, 'workspace'); assert.equal(finalWorkspace.templates.find(t => t.id === template.id).active, false); assert.ok(finalWorkspace.letters.some(l => l.id === id)); pass('Template yang digunakan dinonaktifkan tanpa merusak surat atau arsip');
console.log(`\n${checks} pengujian integrasi lulus. Surat arsip: ${id}`);
