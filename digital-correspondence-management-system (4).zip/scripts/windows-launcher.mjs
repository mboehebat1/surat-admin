import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { constants } from 'node:fs';
import { access, copyFile, readFile, readdir, writeFile } from 'node:fs/promises';
import { createServer } from 'node:net';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import * as util from 'node:util';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const windows = process.platform === 'win32';
const allowed = new Set(['--dev', '--cepat', '--build-ulang', '--periksa', '--tanpa-browser', '--help']);
let activeChild;
let stopping = false;

export function parseArguments(args) {
  for (const argument of args) if (!allowed.has(argument)) throw new Error(`Opsi tidak dikenal: ${argument}. Gunakan --help untuk panduan.`);
  if (['--dev', '--cepat', '--build-ulang'].filter(mode => args.includes(mode)).length > 1) throw new Error('Pilih salah satu mode: --dev, --cepat, atau --build-ulang.');
  return { development: args.includes('--dev'), quick: args.includes('--cepat'), rebuild: args.includes('--build-ulang'), check: args.includes('--periksa'), browser: !args.includes('--tanpa-browser'), help: args.includes('--help') };
}
export function shouldRebuild({ development = false, quick = false, rebuild = false, dependenciesChanged = false, hasBuild = false, previousFingerprint, currentFingerprint }) {
  if (development) return false;
  if (rebuild || dependenciesChanged || !hasBuild) return true;
  if (quick) return false;
  return !previousFingerprint || previousFingerprint !== currentFingerprint;
}
export async function fingerprintProject(projectRoot = root) {
  const hash = createHash('sha256').update(`esurat-build-v1:${process.platform}:${process.arch}:${process.versions.node.split('.')[0]}`);
  async function visit(relative) {
    const path = join(projectRoot, relative);
    let directory;
    try { directory = await readdir(path, { withFileTypes: true }); }
    catch (error) { if (error.code === 'ENOENT') return; throw error; }
    for (const entry of directory.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0)) {
      const child = relative ? `${relative}/${entry.name}` : entry.name;
      if (entry.isDirectory()) await visit(child);
      else if (entry.isFile()) { hash.update(`file:${child}\0`); hash.update(await readFile(join(projectRoot, child))); }
    }
  }
  for (const folder of ['src', 'public', 'scripts', 'drizzle']) await visit(folder);
  for (const filename of ['package.json', 'package-lock.json', 'next.config.ts', 'next.config.js', 'next.config.mjs', 'tsconfig.json', 'next-env.d.ts', 'postcss.config.mjs', 'postcss.config.js', '.env', '.env.local', '.env.production', '.env.production.local']) {
    const path = join(projectRoot, filename);
    if (await exists(path)) { hash.update(`file:${filename}\0`); hash.update(await readFile(path)); }
  }
  for (const key of Object.keys(process.env).filter(key => key.startsWith('NEXT_PUBLIC_')).sort()) hash.update(`${key}=${process.env[key]}\0`);
  return hash.digest('hex');
}
export function parsePort(value = '3000') {
  if (!/^\d+$/.test(String(value))) throw new Error('PORT harus berupa angka antara 1024 dan 65535.');
  const number = Number(value);
  if (number < 1024 || number > 65535) throw new Error('PORT harus berupa angka antara 1024 dan 65535.');
  return number;
}
export function validateDatabaseUrl(value) {
  if (!value) throw new Error('DATABASE_URL belum diisi. Lengkapi .env lalu jalankan kembali.');
  let url;
  try { url = new URL(value); } catch { throw new Error('Format DATABASE_URL tidak valid. Gunakan alamat koneksi PostgreSQL.'); }
  if (!['postgres:', 'postgresql:'].includes(url.protocol) || !url.hostname || url.pathname.length < 2) throw new Error('DATABASE_URL harus mengarah ke database PostgreSQL yang sudah dibuat.');
  if (/GANTI_|CHANGE_ME|YOUR_PASSWORD/i.test(value)) throw new Error('Ganti placeholder password PostgreSQL di .env terlebih dahulu.');
  return url;
}
export async function findAvailablePort(preferred) {
  for (let port = preferred; port <= Math.min(preferred + 9, 65535); port++) {
    const free = await new Promise((resolve, reject) => {
      const server = createServer();
      server.once('error', error => error.code === 'EADDRINUSE' || error.code === 'EACCES' ? resolve(false) : reject(error));
      server.listen(port, '127.0.0.1', () => server.close(() => resolve(true)));
    });
    if (free) return port;
  }
  throw new Error('Tidak ada port lokal tersedia dalam rentang yang dicoba. Ubah PORT di .env. Tidak ada aplikasi lain yang dihentikan.');
}
async function exists(path) { try { await access(path); return true; } catch { return false; } }
function help() {
  console.log('\nCara pakai dari folder proyek:\n');
  console.log('  jalankan-esurat.bat                 Klik dua kali: persiapan dan build otomatis bila diperlukan');
  console.log('  jalankan-esurat.bat --cepat         Pakai build tersedia tanpa memeriksa perubahan kode');
  console.log('  jalankan-esurat.bat --build-ulang   Paksa validasi dan build ulang');
  console.log('  jalankan-esurat.bat --dev           Jalankan mode pengembangan');
  console.log('  jalankan-esurat.bat --periksa       Periksa konfigurasi dan database saja');
  console.log('  jalankan-esurat.bat --tanpa-browser Jangan membuka browser otomatis');
  console.log('\nPrasyarat: Node.js 22 LTS atau lebih baru, npm, PostgreSQL aktif, dan database yang sudah dibuat.');
  console.log('Panduan lengkap: README-WINDOWS.md. File BAT harus digunakan bersama proyek lengkap.\n');
}
async function loadEnvironment(development, readOnly) {
  const mode = development ? 'development' : 'production';
  process.env.NODE_ENV = mode;
  const paths = [`.env.${mode}.local`, '.env.local', `.env.${mode}`, '.env'];
  for (const filename of paths) {
    const path = join(root, filename);
    if (!await exists(path)) continue;
    const parsed = util.parseEnv(await readFile(path, 'utf8'));
    for (const [key, value] of Object.entries(parsed)) if (process.env[key] === undefined) process.env[key] = value;
  }
  if (!process.env.DATABASE_URL) {
    const destination = join(root, '.env');
    if (!readOnly && !await exists(destination)) {
      await copyFile(join(root, '.env.windows.example'), destination, constants.COPYFILE_EXCL);
      console.log('[INFO] Contoh .env telah dibuat. Konfigurasi yang sudah ada tidak ditimpa.');
    }
    throw new Error('DATABASE_URL belum tersedia. Buka .env, isi koneksi PostgreSQL sesuai .env.windows.example, lalu jalankan kembali. Buat database esurat_db melalui pgAdmin terlebih dahulu.');
  }
  validateDatabaseUrl(process.env.DATABASE_URL);
  return parsePort(process.env.PORT || '3000');
}
function stopActive() {
  const child = activeChild;
  if (!child?.pid || child.exitCode !== null || child.signalCode !== null) return;
  if (windows) spawnSync('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
  else child.kill('SIGTERM');
}
function run(command, args, { capture = false, timeout = 0 } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: root, env: process.env, stdio: capture ? ['ignore', 'pipe', 'pipe'] : 'inherit', windowsHide: false });
    activeChild = child;
    let output = '';
    let timer;
    if (capture) {
      child.stdout.on('data', chunk => { output += chunk.toString(); });
      child.stderr.on('data', () => {}); // Never echo connection details from a failed database subprocess.
    }
    if (timeout) timer = setTimeout(() => { stopActive(); reject(new Error('Pemeriksaan PostgreSQL melewati batas waktu. Periksa layanan, host, dan port database.')); }, timeout);
    child.once('error', error => { clearTimeout(timer); if (activeChild === child) activeChild = undefined; reject(new Error(`Proses tidak dapat dijalankan (${error.code || 'error'}). Periksa instalasi Node.js dan npm.`)); });
    child.once('close', code => {
      clearTimeout(timer);
      if (activeChild === child) activeChild = undefined;
      if (stopping) { resolve({ output, code: 0 }); return; }
      if (capture) { resolve({ output, code }); return; }
      if (code !== 0) reject(new Error(`Proses gagal dengan kode ${code ?? 'tidak diketahui'}. Periksa pesan di atas.`));
      else resolve({ output, code });
    });
  });
}
const nodeScript = (script, args = [], options) => run(process.execPath, [join(root, script), ...args], options);
async function dependencies(readOnly) {
  const required = ['next/dist/bin/next', 'tsx/dist/cli.mjs', 'typescript/bin/tsc', 'pg/package.json', 'drizzle-orm/package.json'];
  const ready = (await Promise.all(required.map(p => exists(join(root, 'node_modules', p))))).every(Boolean);
  if (readOnly) {
    if (!ready) throw new Error('Dependensi belum terpasang. Jalankan BAT tanpa --periksa terlebih dahulu.');
    return false;
  }
  const hasLock = await exists(join(root, 'package-lock.json'));
  const manifest = await readFile(join(root, hasLock ? 'package-lock.json' : 'package.json'));
  const fingerprint = createHash('sha256').update(manifest).update(`${process.platform}:${process.arch}:${process.versions.node.split('.')[0]}`).digest('hex');
  const stamp = join(root, 'node_modules', '.esurat-windows-dependencies');
  let previous = '';
  if (await exists(stamp)) previous = (await readFile(stamp, 'utf8')).trim();
  if (ready && previous === fingerprint) { console.log('[OK] Dependensi sudah sesuai.'); return false; }
  console.log('[1/5] Memasang dependensi. Koneksi internet diperlukan pada pemasangan pertama...');
  const install = hasLock ? 'ci' : 'install';
  if (windows) await run(process.env.ComSpec || 'cmd.exe', ['/d', '/s', '/c', `npm.cmd ${install} --include=dev`]);
  else await run('npm', [install, '--include=dev']);
  const updated = await readFile(join(root, await exists(join(root, 'package-lock.json')) ? 'package-lock.json' : 'package.json'));
  const actual = createHash('sha256').update(updated).update(`${process.platform}:${process.arch}:${process.versions.node.split('.')[0]}`).digest('hex');
  await writeFile(stamp, `${actual}\n`, 'utf8');
  return true;
}
async function database(prepare) {
  const result = await nodeScript('node_modules/tsx/dist/cli.mjs', [join(root, 'scripts', 'windows-database.ts'), prepare ? '--prepare' : '--check'], { capture: true, timeout: 30000 });
  let message;
  try { message = JSON.parse(result.output.trim()); } catch { throw new Error('Pemeriksaan database gagal. Pastikan proyek lengkap, DATABASE_URL benar, dan PostgreSQL aktif.'); }
  if (result.code !== 0 || !message.ok) throw new Error(message.message || 'Database belum dapat digunakan.');
  return message;
}
async function waitUntilHealthy(port, childRunning) {
  const until = Date.now() + 90000;
  while (Date.now() < until) {
    if (!childRunning()) throw new Error('Server berhenti sebelum siap digunakan. Periksa pesan pada terminal.');
    try {
      const response = await fetch(`http://127.0.0.1:${port}/api/health`, { signal: AbortSignal.timeout(2500) });
      if (response.ok && (await response.json()).ok === true) return;
    } catch { /* Retry while Next.js starts or compiles the development route. */ }
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  throw new Error('Server belum sehat setelah 90 detik. Periksa koneksi PostgreSQL dan pesan terminal.');
}
async function main() {
  const options = parseArguments(process.argv.slice(2));
  if (options.help) { help(); return; }
  if (Number(process.versions.node.split('.')[0]) < 22 || typeof util.parseEnv !== 'function') throw new Error('Gunakan Node.js 22 LTS atau lebih baru. Unduh melalui https://nodejs.org/');
  if (!windows && !options.check) throw new Error('Peluncur ini ditujukan untuk Windows. Opsi --periksa dan --help dapat digunakan pada sistem lain untuk verifikasi.');
  process.chdir(root);
  console.log(`Node.js ${process.versions.node} | ${process.platform} ${process.arch}`);
  const preferredPort = await loadEnvironment(options.development, options.check);
  const dependenciesChanged = await dependencies(options.check);
  console.log('[2/5] Memeriksa PostgreSQL dan skema E-SURAT...');
  const state = await database(!options.check);
  if (options.check) {
    console.log(`[OK] PostgreSQL terhubung. Skema: ${state.status}; ${state.matched}/${state.total} tabel.`);
    if (state.status === 'empty') console.log('[INFO] Jalankan BAT normal untuk menerapkan migrasi ke database kosong.');
    if (state.status === 'partial') throw new Error('Skema database belum lengkap. Periksa migrasi secara manual sebelum menjalankan aplikasi.');
    console.log('[OK] Pemeriksaan selesai. Tidak ada server yang dijalankan atau data yang diubah.');
    return;
  }
  console.log(`[OK] ${state.total} tabel siap. ${state.migrated ? 'Migrasi diperiksa/dijalankan.' : 'Skema yang sudah ada dipertahankan.'}`);
  if (process.env.DEMO_MODE === 'false' && !state.hasUsers) {
    if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 12) throw new Error('Workspace non-demo baru memerlukan ADMIN_EMAIL dan ADMIN_PASSWORD minimal 12 karakter di .env.');
  }
  if (process.env.DEMO_MODE !== 'false') console.log('[INFO] Mode demo aktif. Jangan gunakan workspace demo untuk dokumen nyata.');
  if (!options.development) {
    const buildIdPath = join(root, '.next', 'BUILD_ID');
    const stampPath = join(root, '.next', 'esurat-launcher-build.json');
    const hasBuild = await exists(buildIdPath);
    const currentFingerprint = await fingerprintProject();
    let previousFingerprint;
    if (hasBuild && await exists(stampPath)) {
      try {
        const cached = JSON.parse(await readFile(stampPath, 'utf8'));
        if (cached.version === 1 && cached.buildId === (await readFile(buildIdPath, 'utf8')).trim()) previousFingerprint = cached.fingerprint;
      } catch { /* A damaged or stale stamp requires a fresh build. */ }
    }
    if (shouldRebuild({ ...options, dependenciesChanged, hasBuild, previousFingerprint, currentFingerprint })) {
      console.log('[3/5] Build pertama, perubahan terdeteksi, atau build ulang diminta. Memvalidasi dan membangun...');
      await nodeScript('node_modules/next/dist/bin/next', ['typegen']);
      await nodeScript('node_modules/typescript/bin/tsc', ['--noEmit', '--pretty', 'false']);
      await nodeScript('node_modules/next/dist/bin/next', ['build']);
      await writeFile(stampPath, JSON.stringify({ version: 1, fingerprint: currentFingerprint, buildId: (await readFile(buildIdPath, 'utf8')).trim() }) + '\n', 'utf8');
    } else if (options.quick) console.log('[3/5] Menggunakan build tersedia. Mode --cepat melewati pemeriksaan perubahan kode; mode bawaan lebih aman.');
    else console.log('[3/5] Tidak ada perubahan. Build yang masih sesuai digunakan kembali agar aplikasi lebih cepat dibuka.');
  } else console.log('[3/5] Mode pengembangan: perubahan kode akan dimuat otomatis.');
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) console.log(`[INFO] Port ${preferredPort} sedang digunakan. E-SURAT memakai port ${port}; aplikasi lain tidak dihentikan.`);
  process.env.PORT = String(port);
  console.log('[4/5] Menjalankan server lokal dan menunggu healthcheck...');
  const server = nodeScript('node_modules/next/dist/bin/next', [options.development ? 'dev' : 'start', '--hostname', '127.0.0.1', '--port', String(port)]);
  let serverFailure;
  let running = true;
  const settledServer = server.then(() => { running = false; }, error => { running = false; serverFailure = error; });
  await waitUntilHealthy(port, () => running && !stopping);
  const address = `http://localhost:${port}`;
  console.log(`\n[5/5] E-SURAT siap: ${address}`);
  console.log('Akses lokal saja. Biarkan jendela ini terbuka selama aplikasi digunakan.');
  console.log('Tekan Ctrl+C untuk menghentikan server yang dijalankan oleh peluncur ini.\n');
  if (options.browser && windows) {
    const browser = spawn('rundll32.exe', ['url.dll,FileProtocolHandler', address], { detached: true, stdio: 'ignore', windowsHide: true });
    browser.on('error', () => console.log(`[INFO] Browser tidak terbuka otomatis. Buka ${address} secara manual.`));
    browser.unref();
  }
  await settledServer;
  if (serverFailure && !stopping) throw serverFailure;
}
function interrupt() { if (stopping) return; stopping = true; console.log('\nMenghentikan proses E-SURAT milik peluncur...'); stopActive(); }
const entryUrl = process.argv[1] ? pathToFileURL(resolve(process.argv[1])).href : '';
if (entryUrl && (windows ? entryUrl.toLowerCase() === import.meta.url.toLowerCase() : entryUrl === import.meta.url)) {
  process.on('SIGINT', interrupt);
  process.on('SIGTERM', interrupt);
  process.on('exit', stopActive);
  main().catch(error => { stopActive(); if (!stopping) { console.error(`\n[GAGAL] ${error.message}\n`); console.error('Panduan: README-WINDOWS.md'); process.exitCode = 1; } });
}
