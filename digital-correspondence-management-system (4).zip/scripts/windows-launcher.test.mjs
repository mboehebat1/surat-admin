import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer } from 'node:net';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { parseArguments, parsePort, validateDatabaseUrl, findAvailablePort, shouldRebuild, fingerprintProject } from './windows-launcher.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));

test('mode bawaan otomatis dan membuka browser tanpa argumen', () => {
  assert.deepEqual(parseArguments([]), { development: false, quick: false, rebuild: false, check: false, browser: true, help: false });
});
test('mode cepat, pengembangan, build ulang, dan pemeriksaan tervalidasi', () => {
  assert.equal(parseArguments(['--cepat', '--tanpa-browser']).quick, true);
  assert.equal(parseArguments(['--dev', '--tanpa-browser']).browser, false);
  assert.equal(parseArguments(['--build-ulang']).rebuild, true);
  assert.equal(parseArguments(['--periksa']).check, true);
  assert.throws(() => parseArguments(['--dev', '--cepat']), /salah satu/);
  assert.throws(() => parseArguments(['--cepat', '--build-ulang']), /salah satu/);
  assert.throws(() => parseArguments(['--dev', '--build-ulang']), /salah satu/);
  assert.throws(() => parseArguments(['--tidak-ada']), /tidak dikenal/);
});
test('build pertama dan stamp yang hilang selalu memerlukan build', () => {
  assert.equal(shouldRebuild({ hasBuild: false }), true);
  assert.equal(shouldRebuild({ hasBuild: true, currentFingerprint: 'baru' }), true);
});
test('klik berikutnya memakai build yang masih sama', () => {
  assert.equal(shouldRebuild({ hasBuild: true, previousFingerprint: 'sama', currentFingerprint: 'sama' }), false);
});
test('perubahan kode dan konfigurasi memicu build otomatis', () => {
  assert.equal(shouldRebuild({ hasBuild: true, previousFingerprint: 'lama', currentFingerprint: 'baru' }), true);
});
test('pemasangan dependensi baru selalu memicu build termasuk mode cepat', () => {
  assert.equal(shouldRebuild({ quick: true, dependenciesChanged: true, hasBuild: true, previousFingerprint: 'sama', currentFingerprint: 'sama' }), true);
});
test('mode build ulang dipatuhi dan mode pengembangan tidak menjalankan build produksi', () => {
  assert.equal(shouldRebuild({ rebuild: true, hasBuild: true, previousFingerprint: 'sama', currentFingerprint: 'sama' }), true);
  assert.equal(shouldRebuild({ development: true, hasBuild: false }), false);
  assert.equal(shouldRebuild({ quick: true, hasBuild: true, previousFingerprint: 'lama', currentFingerprint: 'baru' }), false);
});
test('fingerprint stabil, menangkap perubahan sumber, dan mengabaikan output build', async () => {
  const temporary = await mkdtemp(join(tmpdir(), 'esurat-launcher-'));
  try {
    await mkdir(join(temporary, 'src'), { recursive: true });
    await writeFile(join(temporary, 'src', 'contoh.ts'), 'export const nilai = 1;');
    const initial = await fingerprintProject(temporary);
    assert.equal(initial, await fingerprintProject(temporary));
    await mkdir(join(temporary, '.next'), { recursive: true });
    await writeFile(join(temporary, '.next', 'cache'), 'output tidak mengubah sumber');
    assert.equal(initial, await fingerprintProject(temporary));
    await writeFile(join(temporary, 'src', 'contoh.ts'), 'export const nilai = 2;');
    assert.notEqual(initial, await fingerprintProject(temporary));
  } finally { await rm(temporary, { recursive: true, force: true }); }
});
test('port harus berupa bilangan bulat dalam rentang aman', () => {
  assert.equal(parsePort(), 3000);
  assert.equal(parsePort('3100'), 3100);
  for (const value of ['0', '80', '65536', '3000 & calc', '1.5', 'NaN', '']) assert.throws(() => parsePort(value));
});
test('koneksi database dan placeholder diperiksa tanpa membocorkan kredensial', () => {
  assert.equal(validateDatabaseUrl('postgresql://example:example@localhost:5432/esurat_db').pathname, '/esurat_db');
  assert.throws(() => validateDatabaseUrl(), /belum diisi/);
  assert.throws(() => validateDatabaseUrl('not-a-url'), /tidak valid/);
  assert.throws(() => validateDatabaseUrl('https://example.test/database'), /PostgreSQL/);
  assert.throws(() => validateDatabaseUrl('postgresql://localhost/'), /PostgreSQL/);
  assert.throws(() => validateDatabaseUrl('postgresql://postgres:GANTI_PASSWORD_POSTGRES@localhost/esurat_db'), /placeholder/);
});
test('port yang dipakai tidak dihentikan dan port pengganti dipilih', async () => {
  const server = createServer();
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  try {
    const port = server.address().port;
    const available = await findAvailablePort(port);
    assert.ok(available > port && available <= port + 9);
    assert.equal(server.listening, true);
  } finally { await new Promise(resolve => server.close(resolve)); }
});
test('salinan BAT sama dan memakai CRLF untuk Windows', async () => {
  const original = await readFile(new URL('../jalankan-esurat.bat', import.meta.url));
  const download = await readFile(new URL('../public/unduhan/jalankan-esurat.bat', import.meta.url));
  assert.deepEqual(original, download);
  const text = original.toString('utf8');
  assert.ok(text.startsWith('@echo off\r\n'));
  assert.equal(/(?<!\r)\n/.test(text), false);
  assert.ok(text.includes('DisableDelayedExpansion'));
  assert.ok(text.includes('pushd "%ESURAT_ROOT%"'));
  assert.ok(text.includes('node "scripts\\windows-launcher.mjs" %*'));
});
test('contoh konfigurasi tidak menggunakan password operasional', async () => {
  const sample = await readFile(new URL('../.env.windows.example', import.meta.url), 'utf8');
  assert.ok(sample.includes('GANTI_PASSWORD_POSTGRES'));
  assert.ok(sample.includes('DEMO_MODE=true'));
});
test('bantuan CLI berjalan tanpa memasang dependensi atau menjalankan server', () => {
  const result = spawnSync(process.execPath, ['scripts/windows-launcher.mjs', '--help'], { cwd: root, encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  assert.ok(result.stdout.includes('jalankan-esurat.bat --periksa'));
  assert.ok(result.stdout.includes('jalankan-esurat.bat --build-ulang'));
  assert.ok(result.stdout.includes('Node.js 22 LTS'));
  assert.ok(!result.stdout.includes('[5/5]'));
});
