import { resolve } from "node:path";
import { existsSync } from "node:fs";
import { db, pool } from "@/db";
import * as schema from "@/db/schema";
import { getTableName, sql } from "drizzle-orm";
import { migrate } from "drizzle-orm/node-postgres/migrator";

type Executor = Pick<typeof db, "execute">;
const required = Object.values(schema).map(table => getTableName(table)).sort();

async function inspect(executor: Executor = db) {
  const result = await executor.execute<{ tablename: string }>(sql`select tablename from pg_catalog.pg_tables where schemaname = 'public'`);
  const names = new Set(result.rows.map(row => row.tablename));
  const missing = required.filter(name => !names.has(name));
  const matched = required.length - missing.length;
  const history = await executor.execute<{ relation: string | null }>(sql`select to_regclass('drizzle.__drizzle_migrations')::text as relation`);
  return { status: missing.length === 0 ? "ready" : matched === 0 && names.size === 0 ? "empty" : "partial", matched, total: required.length, missing, tracked: Boolean(history.rows[0]?.relation) };
}

async function prepare() {
  return db.transaction(async tx => {
    await tx.execute(sql`select pg_advisory_xact_lock(7263102)`);
    const before = await inspect(tx);
    if (before.status === "partial" && !before.tracked) throw new Error("Database berisi skema yang tidak lengkap atau tabel aplikasi lain. Gunakan database kosong khusus E-SURAT, atau periksa migrasi secara manual. Tidak ada data yang diubah.");
    let migrated = false;
    if (before.status === "empty" || before.tracked) {
      const folder = resolve(process.cwd(), "drizzle");
      if (!existsSync(resolve(folder, "meta", "_journal.json"))) throw new Error("Berkas migrasi tidak ditemukan. Pastikan seluruh folder drizzle ikut disalin.");
      // The outer advisory lock serializes launchers; the migrator uses its own transaction.
      await migrate(db, { migrationsFolder: folder });
      migrated = true;
    }
    const after = await inspect(tx);
    if (after.status !== "ready") throw new Error("Skema database belum sesuai dengan versi aplikasi. Periksa migrasi secara manual sebelum melanjutkan.");
    const users = await tx.execute<{ count: string }>(sql`select count(*)::text as count from users`);
    return { ...after, migrated, hasUsers: Number(users.rows[0]?.count || 0) > 0 };
  });
}

function safeError(error: unknown) {
  let current: unknown = error;
  for (let level = 0; level < 5 && current && typeof current === "object"; level++) {
    const value = current as { code?: string; cause?: unknown };
    if (value.code === "ECONNREFUSED") return "PostgreSQL belum berjalan atau alamat/port DATABASE_URL tidak dapat dihubungi. Aktifkan layanan PostgreSQL di Windows.";
    if (value.code === "3D000") return "Database pada DATABASE_URL belum dibuat. Buat database melalui pgAdmin terlebih dahulu, lalu jalankan kembali.";
    if (value.code === "28P01" || value.code === "28000") return "Login PostgreSQL gagal. Periksa username dan password pada DATABASE_URL.";
    if (value.code === "42501") return "Pengguna PostgreSQL tidak memiliki izin yang diperlukan untuk skema atau migrasi.";
    current = value.cause;
  }
  if (error instanceof Error && /Database berisi|Berkas migrasi|Skema database/.test(error.message)) return error.message;
  return "Database tidak dapat disiapkan. Periksa PostgreSQL, DATABASE_URL, izin akses, dan kelengkapan folder migrasi. Rincian koneksi tidak ditampilkan demi keamanan.";
}

async function main() {
  try {
    const mode = process.argv[2] || "--check";
    if (!["--check", "--prepare"].includes(mode)) throw new Error("Mode database tidak dikenal.");
    await db.execute(sql`select 1`);
    const result = mode === "--prepare" ? await prepare() : await inspect();
    console.log(JSON.stringify({ ok: true, ...result }));
  } catch (error) {
    console.log(JSON.stringify({ ok: false, message: safeError(error) }));
    process.exitCode = 1;
  } finally { await pool.end(); }
}
void main();
