# E-SURAT

Aplikasi manajemen persuratan digital berbahasa Indonesia. Next.js App Router, React, PostgreSQL, Drizzle ORM, Lucide, Docxtemplater, PizZip, DOCX, dan pdf-lib. Seluruh data operasional dan dokumen disimpan di PostgreSQL, bukan array statis atau localStorage.

## Modul

- Dashboard statistik aktual, grafik bulanan/mingguan, status, tindakan, dan aktivitas.
- Autentikasi sesi HTTP-only dengan token acak yang di-hash, scrypt password hashing, lima role, CSRF origin checking, dan pembatasan percobaan login.
- Template DOCX dengan deteksi placeholder lintas text run Word, pengaturan label/tipe/wajib, PDF referensi, duplikasi, status aktif, dan penghapusan aman.
- Wizard surat, formulir dinamis, autosave draft ke database, lampiran privat, pratinjau, revisi, dan pengajuan ulang.
- Workflow berurutan, assignee/role per tahap, catatan, penolakan, revisi, identitas dan waktu persetujuan. Pembuat dilarang menyetujui surat sendiri.
- Penomoran atomik dan snapshot arsip saat persetujuan akhir; penguncian baris menghindari persetujuan/nomor ganda.
- Monitoring, pencarian/filter, arsip, notifikasi polling 30 detik, audit append-only melalui aplikasi, laporan PDF/XLSX, backup JSON.
- Distribusi internal berupa pencatatan tujuan, perubahan status, audit, dan notifikasi ke pembuat. Tidak mengirim email eksternal.

## Struktur

- `src/app`: halaman dan route REST bertingkat.
- `src/components`: shell, dashboard, daftar, grafik, wizard dan dialog.
- `src/lib/api.ts`: handler REST dan validasi Zod.
- `src/lib/auth.ts`: sesi, hashing, pemeriksaan asal permintaan dan akses.
- `src/lib/letter-service.ts`: transaksi state machine persetujuan.
- `src/lib/documents.ts`: pembacaan DOCX, pendeteksian field, ekspor DOCX/PDF.
- `src/lib/spreadsheet.ts`: ekspor XLSX OOXML formula-free.
- `src/lib/queries.ts`: query terpusat dan pembatasan akses record.
- `src/db/schema.ts`: 18 tabel beserta foreign key, unique constraint dan indeks.
- `drizzle/0000_esurat_initial.sql`: migrasi skema awal.
- `public/fonts`: font lokal tanpa ketergantungan permintaan eksternal.

## Menjalankan

**Windows:** tersedia `jalankan-esurat.bat` untuk persiapan dan menjalankan aplikasi dengan klik dua kali. Panduan prasyarat, konfigurasi, dan mode tambahan ada di [README-WINDOWS.md](README-WINDOWS.md). Salinan BAT tersedia pada `/unduhan/jalankan-esurat.bat`.

1. Siapkan `DATABASE_URL` menuju PostgreSQL.
2. Pasang dependensi menggunakan package manager.
3. Terapkan skema dengan `npx drizzle-kit push` atau migration SQL yang disertakan. Konfigurasi sandbox ada pada `drizzle.config.json`; gunakan kredensial database lingkungan Anda untuk deployment lain.
4. Jalankan `npm run dev` untuk pengembangan, atau `npm run build` kemudian runtime produksi yang sesuai.
5. `/api/health` memeriksa koneksi PostgreSQL.

Inisialisasi idempoten dilindungi advisory transaction lock. Permintaan API pertama menyiapkan konfigurasi dan akun jika database belum berisi pengguna.

## Workspace demo

Untuk preview, mode demo aktif kecuali `DEMO_MODE=false`. Record contoh benar-benar disimpan di database dan perubahan bertahan setelah refresh/restart. Login demo otomatis pertama kali dapat diakhiri melalui menu akun. Setelah logout, login manual tersedia.

Kata sandi seluruh akun demo: **ESurat!2026**.

| Email | Role |
|---|---|
| admin@esurat.id | Super Admin |
| rina@esurat.id | Admin Persuratan |
| siti@esurat.id | Pembuat Surat |
| dimas@esurat.id | Pembuat Surat |
| budi@esurat.id | Pemeriksa |
| hendra@esurat.id | Pejabat Penyetuju |

## Produksi

Gunakan database **baru/kosong**, HTTPS, dan variabel lingkungan berikut sebelum permintaan pertama:

- `DATABASE_URL`: database produksi, role dengan least privilege.
- `DEMO_MODE=false`: menonaktifkan endpoint dan login demo otomatis.
- `ADMIN_EMAIL`: email administrator pertama.
- `ADMIN_PASSWORD`: kata sandi awal minimal 12 karakter, dari secret manager.
- `ADMIN_NAME`: nama administrator, opsional.

Tidak ada password produksi yang di-hardcode. Inisialisasi produksi tidak membuat surat contoh atau akun demo. Role, departemen, template dasar dan workflow tetap disiapkan. Super Admin dapat menambahkan akun dan menentukan assignee workflow dari Pengaturan. Jangan menggunakan database demo untuk dokumen nyata, dan jangan sekadar mematikan mode demo pada database yang masih memiliki akun demo.

## Batasan dokumen dan persetujuan

- Gunakan placeholder `{{nama_field}}`, huruf/angka/underscore; maksimum 60 field.
- Nomor surat hanya diberikan setelah persetujuan akhir. Format mendukung `{nomor}`, `{bulan}`, `{tahun}`.
- DOCX yang diunggah dipertahankan formatnya saat diekspor ke DOCX.
- **PDF adalah hasil tata letak teks standar**, bukan konversi pixel-identik dari Word. Tabel, gambar, dan tata letak DOCX kompleks tidak direproduksi pada PDF/preview. Untuk kebutuhan fidelitas penuh, tambahkan layanan LibreOffice terisolasi sebelum produksi.
- Persetujuan internal mencatat identitas, waktu, tahap, versi dan audit. **Bukan tanda tangan elektronik tersertifikasi** dan bukan integrasi PSrE.
- Lampiran dibatasi 5 MB per file dan 5 file per surat, dengan validasi MIME dan signature. File tidak tersedia melalui URL public; setiap unduhan memeriksa akses.
- Perubahan workflow menghasilkan versi baru. Surat berjalan mempertahankan workflow sebelumnya.
- Template yang telah digunakan dinonaktifkan, bukan dihapus. Surat dengan proses persetujuan tidak dapat dihapus sebagai draft.

## API

`GET /api/workspace`, `GET/POST /api/auth`, `POST /api/letters`, `GET/PATCH/DELETE /api/letters/:id`, `POST /api/letters/:id/action`, `GET /api/letters/:id/download?format=pdf|docx`, `POST /api/letters/:id/attachments`, `GET/DELETE /api/attachments/:id`, `POST /api/template-inspect`, `POST /api/templates`, `PATCH/DELETE /api/templates/:id`, `POST /api/templates/:id/duplicate`, `GET /api/templates/:id/download`, `POST/PATCH /api/users[/:id]`, `DELETE /api/users/:id`, `POST/PATCH /api/workflows[/:id]`, `POST /api/notifications`, `PATCH /api/settings`, `GET /api/reports?format=pdf|xlsx`, `GET /api/backup`.

Mutasi memerlukan sesi serta role yang sesuai. Pengguna biasa hanya menerima surat miliknya. Reviewer/approver harus berwenang pada tahap aktif untuk bertindak. Data pengguna yang dikirim ke browser tidak memuat hash password atau token sesi.

## Backup dan operasi

Pengaturan → Keamanan & Backup mengunduh JSON seluruh tabel dan file base64; tidak menyertakan token sesi. File ini sensitif dan mencakup hash password. Simpan terenkripsi di luar server dengan kebijakan retensi yang sesuai.

Untuk pemulihan produksi, gunakan backup PostgreSQL native (`pg_dump` / `pg_restore`) terjadwal, teruji, dengan akses operator terbatas. Karena dokumen berada di database, backup PostgreSQL juga memuat dokumen. Ekspor JSON aplikasi merupakan snapshot logis tambahan, bukan pengganti backup PostgreSQL transaksional. Tidak ada endpoint restore otomatis yang dapat menimpa data operasional.

Audit log tidak dapat diubah lewat API, tetapi operator database tetap berwenang secara teknis. Untuk kebutuhan kepatuhan tinggi, gunakan database role terpisah, kebijakan append-only DB dan log eksternal. Pembatasan login di memori berlaku per instance; deployment multi-instance sebaiknya memakai rate limiter terdistribusi. Notifikasi memakai polling, bukan WebSocket atau push email.

## Validasi

`npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, dan `npm run build`, kemudian healthcheck runtime platform. Lakukan pengujian workflow lintas akun dan uji pemulihan backup sebelum menerima dokumen nyata.

## Pengujian integrasi dan browser

- `node scripts/smoke-test.mjs`: 21 pemeriksaan API pada workspace demo, termasuk workflow lintas role, revisi, unduhan, snapshot, RBAC dan backup. Membuat satu surat arsip dan menonaktifkan template pengujiannya; gunakan hanya database demo/pengujian.
- `npx playwright install --with-deps chromium`, lalu `node scripts/browser-check.mjs`: pengujian navigasi, form, autosave, template upload, monitoring, pengguna, login dan ponsel. Screenshot tersimpan di `artifacts/`. Membuat/mengaktifkan lalu menonaktifkan akun pengujian Nadia Putri.
- `TEST_BASE_URL` dapat digunakan untuk mengarahkan pengujian ke lingkungan pengujian tersendiri. Jangan menjalankannya terhadap workspace produksi.
- Audit `npm audit --omit=dev` diperiksa terpisah dari advisori tool pengembangan.
