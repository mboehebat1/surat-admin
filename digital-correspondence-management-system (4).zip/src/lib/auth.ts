import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { departments, roles, sessions, users } from "@/db/schema";
import type { User } from "./types";

export class AppError extends Error { constructor(message: string, public status = 400) { super(message); } }
export function hashPassword(password: string) { const salt = randomBytes(16).toString("hex"); return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`; }
export function verifyPassword(password: string, hash: string) { const [salt, key] = hash.split(":"); if (!salt || !key) return false; const a = Buffer.from(key, "hex"); const b = scryptSync(password, salt, 64); return a.length === b.length && timingSafeEqual(a, b); }
const tokenHash = (v: string) => createHash("sha256").update(v).digest("hex");
export async function createSession(userId: string) { const token = randomBytes(32).toString("hex"); await db.insert(sessions).values({ tokenHash: tokenHash(token), userId, expiresAt: new Date(Date.now() + 86400 * 1000 * 7) }); const c = await cookies(); c.set("esurat_session", token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 86400 * 7 }); }
export async function currentUser(): Promise<User | null> { const token = (await cookies()).get("esurat_session")?.value; if (!token) return null; const [row] = await db.select({ id: users.id, name: users.name, email: users.email, roleId: users.roleId, departmentId: users.departmentId, department: departments.name, active: users.active }).from(sessions).innerJoin(users, eq(sessions.userId, users.id)).innerJoin(departments, eq(users.departmentId, departments.id)).innerJoin(roles, eq(users.roleId, roles.id)).where(and(eq(sessions.tokenHash, tokenHash(token)), gt(sessions.expiresAt, new Date()), eq(users.active, true))); return row ?? null; }
export async function requireUser(allowed?: string[]): Promise<User> { const u = await currentUser(); if (!u) throw new AppError("Sesi telah berakhir. Silakan masuk kembali.", 401); if (allowed && !allowed.includes(u.roleId)) throw new AppError("Anda tidak memiliki akses untuk tindakan ini.", 403); return u; }
export async function destroySession() { const c = await cookies(); const token = c.get("esurat_session")?.value; if (token) await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash(token))); c.delete("esurat_session"); }
export function checkOrigin(request: Request) { const origin = request.headers.get("origin"); const host = request.headers.get("x-forwarded-host") || request.headers.get("host"); if (origin && new URL(origin).host !== host && new URL(origin).host !== new URL(request.url).host) throw new AppError("Permintaan lintas situs tidak diizinkan.", 403); if (request.headers.get("sec-fetch-site") === "cross-site") throw new AppError("Permintaan tidak diizinkan.", 403); }
const attempts = new Map<string, { count: number; reset: number }>();
export function loginRateLimit(request: Request) { const key = request.headers.get("x-forwarded-for") || "local"; const now = Date.now(); const entry = attempts.get(key); if (entry && entry.reset > now && entry.count >= 12) throw new AppError("Terlalu banyak percobaan. Coba lagi dalam 10 menit.", 429); attempts.set(key, { count: entry && entry.reset > now ? entry.count + 1 : 1, reset: entry && entry.reset > now ? entry.reset : now + 600000 }); }
export function errorResponse(error: unknown) { if (error instanceof AppError) return Response.json({ error: error.message }, { status: error.status }); console.error("E-SURAT:", error); return Response.json({ error: "Terjadi kesalahan pada server. Silakan coba kembali." }, { status: 500 }); }
