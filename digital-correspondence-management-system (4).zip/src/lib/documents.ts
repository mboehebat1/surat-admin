import { inflateRawSync } from "node:zlib";
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { AlignmentType, Document, Packer, Paragraph, TextRun, BorderStyle } from "docx";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import type { Field } from "./types";
import { AppError } from "./auth";

export function detectFields(content: string): Field[] {
  const keys = [...new Set([...content.matchAll(/\{\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\}\}/g)].map(m => m[1]))];
  if (keys.length > 60) throw new AppError("Maksimal 60 field per template.");
  return keys.map((key, order) => ({ key, label: key.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase()), type: key.includes("tanggal") ? "date" : /isi|alamat|catatan/.test(key) ? "textarea" : "text", required: !["nomor_surat", "lampiran"].includes(key), order }));
}
export function inspectDocx(buffer: Buffer) {
  if (buffer.length > 5 * 1024 * 1024 || buffer[0] !== 0x50 || buffer[1] !== 0x4b) throw new AppError("Berkas DOCX tidak valid atau melebihi 5 MB.");
  try {
    // Reject ZIP bombs before the archive is inflated. DOCX is a standard, non-ZIP64 ZIP.
    let end = -1;
    for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 65557); i--) { if (buffer.readUInt32LE(i) === 0x06054b50) { end = i; break; } }
    if (end < 0) throw new AppError("Struktur arsip DOCX tidak valid.");
    const entries = buffer.readUInt16LE(end + 10); let cursor = buffer.readUInt32LE(end + 16); let totalSize = 0;
    if (entries > 1500 || cursor === 0xffffffff) throw new AppError("Arsip DOCX terlalu kompleks.");
    for (let entry = 0; entry < entries; entry++) {
      if (cursor + 46 > buffer.length || buffer.readUInt32LE(cursor) !== 0x02014b50) throw new AppError("Direktori arsip DOCX tidak valid.");
      if (buffer.readUInt16LE(cursor + 8) & 1) throw new AppError("DOCX terenkripsi tidak didukung.");
      const declaredSize = buffer.readUInt32LE(cursor + 24); const compressedSize = buffer.readUInt32LE(cursor + 20); const method = buffer.readUInt16LE(cursor + 10); const local = buffer.readUInt32LE(cursor + 42);
      if (local + 30 > buffer.length || buffer.readUInt32LE(local) !== 0x04034b50) throw new AppError("Entri DOCX tidak valid.");
      const start = local + 30 + buffer.readUInt16LE(local + 26) + buffer.readUInt16LE(local + 28);
      if (start + compressedSize > buffer.length || ![0, 8].includes(method)) throw new AppError("Kompresi DOCX tidak didukung.");
      if (declaredSize > 20 * 1024 * 1024 - totalSize) throw new AppError("Ukuran isi DOCX melebihi batas aman 20 MB.");
      const compressed = buffer.subarray(start, start + compressedSize);
      const actualSize = method === 0 ? compressed.length : inflateRawSync(compressed, { maxOutputLength: 20 * 1024 * 1024 - totalSize }).length;
      if (actualSize !== declaredSize) throw new AppError("Ukuran entri DOCX tidak konsisten.");
      totalSize += actualSize;
      if (totalSize > 20 * 1024 * 1024) throw new AppError("Ukuran isi DOCX melebihi batas aman 20 MB.");
      cursor += 46 + buffer.readUInt16LE(cursor + 28) + buffer.readUInt16LE(cursor + 30) + buffer.readUInt16LE(cursor + 32);
    }
    const zip = new PizZip(buffer);
    if (Object.keys(zip.files).some(p => /vbaProject\.bin$/i.test(p))) throw new AppError("Dokumen yang memuat macro tidak diizinkan.");
    if (!zip.file("word/document.xml")) throw new AppError("Berkas bukan dokumen Word DOCX.");
    const paths = Object.keys(zip.files).filter(p => /^word\/(document|header\d*|footer\d*)\.xml$/.test(p));
    const size = paths.reduce((s, p) => s + zip.files[p].asText().length, 0);
    if (size > 8 * 1024 * 1024) throw new AppError("Isi dokumen terlalu besar.");
    const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true, delimiters: { start: "{{", end: "}}" }, nullGetter: () => "" });
    const content = paths.map(p => doc.getFullText(p)).join("\n");
    const mainXml = zip.file("word/document.xml")!.asText();
    const readable = mainXml.replace(/<\/w:p>/g, "\n").replace(/<w:tab\b[^>]*\/>/g, "\t").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
    if (readable.length > 100000) throw new AppError("Isi template terlalu panjang. Maksimal 100.000 karakter teks.");
    const fields = detectFields(content);
    if (!fields.length) throw new AppError("Tidak ditemukan placeholder. Gunakan format {{nama_field}} dalam DOCX.");
    return { content: readable.trim(), fields };
  } catch (e) { if (e instanceof AppError) throw e; throw new AppError("Template DOCX tidak dapat dibaca. Periksa penulisan placeholder {{nama_field}}."); }
}
export function fillContent(content: string, data: Record<string, string>) { return content.replace(/\{\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\}\}/g, (_, key: string) => data[key] || (key === "nomor_surat" ? "(Nomor diberikan setelah disetujui)" : "—")); }
export async function generateDocx(content: string, data: Record<string, string>, fileData?: string | null) {
  if (fileData) { const zip = new PizZip(Buffer.from(fileData, "base64")); const doc = new Docxtemplater(zip, { paragraphLoop: true, linebreaks: true, delimiters: { start: "{{", end: "}}" }, nullGetter: () => "" }); doc.render(data); return doc.getZip().generate({ type: "nodebuffer", compression: "DEFLATE" }); }
  const lines = fillContent(content, data).split("\n");
  const doc = new Document({ creator: "E-SURAT", title: data.perihal || "Surat Digital", sections: [{ properties: { page: { margin: { top: 1050, bottom: 1050, left: 1200, right: 1200 } } }, children: lines.map((line, index) => new Paragraph({ alignment: index < 3 ? AlignmentType.CENTER : AlignmentType.LEFT, spacing: { after: 140, line: 300 }, ...(index === 2 ? { border: { bottom: { color: "203757", style: BorderStyle.SINGLE, size: 12 } } } : {}), children: [new TextRun({ text: line || " ", bold: index === 0, size: index === 0 ? 30 : 23, font: "Times New Roman" })] })) }] });
  return Packer.toBuffer(doc);
}
function safeText(value: string) { return value.replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"').replace(/[\u2013\u2014]/g, "-").replace(/[^\x09\x0a\x0d\x20-\x7e\xa0-\xff]/g, "?"); }
export async function generatePdf(content: string, title: string, footer?: string) {
  const doc = await PDFDocument.create(); const regular = await doc.embedFont(StandardFonts.TimesRoman); const bold = await doc.embedFont(StandardFonts.TimesRomanBold); let page = doc.addPage([595.28, 841.89]); let y = 784; const margin = 55; const maxWidth = 485;
  const newPage = () => { page = doc.addPage([595.28, 841.89]); y = 784; };
  const lines = safeText(content).split("\n");
  for (let i = 0; i < lines.length; i++) { const font = i === 0 ? bold : regular; const size = i === 0 ? 15 : 11; const words = lines[i].split(/\s+/); const wrapped: string[] = []; let line = ""; for (const word of words) { if (font.widthOfTextAtSize(`${line} ${word}`, size) > maxWidth && line) { wrapped.push(line); line = word; } else line += (line ? " " : "") + word; } wrapped.push(line);
    for (const row of wrapped) { if (y < 70) newPage(); const centered = i < 3; const x = centered ? (595.28 - font.widthOfTextAtSize(row, size)) / 2 : margin; page.drawText(row, { x, y, size, font, color: rgb(0.10, 0.14, 0.21) }); y -= 17; } y -= 5; if (i === 2) { page.drawLine({ start: { x: margin, y: y + 4 }, end: { x: 540, y: y + 4 }, thickness: 1.2, color: rgb(0.12, 0.22, 0.37) }); y -= 12; }
  }
  doc.getPages().forEach((p, i) => { p.drawText(safeText(footer || "Dihasilkan oleh E-SURAT | Persetujuan internal, bukan TTE tersertifikasi."), { x: margin, y: 34, size: 7, font: regular, color: rgb(0.45, 0.49, 0.55) }); p.drawText(`${i + 1} / ${doc.getPageCount()}`, { x: 510, y: 34, size: 8, font: regular }); });
  doc.setTitle(title); doc.setAuthor("E-SURAT"); return Buffer.from(await doc.save());
}
export function validateUpload(file: File, allowed: string[]) { if (!allowed.includes(file.type)) throw new AppError("Jenis berkas tidak didukung. Gunakan PDF, DOCX, JPG, atau PNG."); if (file.size > 5 * 1024 * 1024 || file.size < 1) throw new AppError("Ukuran berkas harus antara 1 byte dan 5 MB."); }
