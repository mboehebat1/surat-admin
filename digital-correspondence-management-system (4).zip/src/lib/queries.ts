import { db } from "@/db";
import * as s from "@/db/schema";
import { asc, desc, eq, sql } from "drizzle-orm";
import { AppError } from "./auth";
import type { User } from "./types";

export async function getLetters(user: User) {
  const rows = await db.select({ id: s.letters.id, title: s.letters.title, number: s.letters.number, templateId: s.letters.templateId, creatorId: s.letters.creatorId, creatorName: s.users.name, creatorRole: s.users.roleId, departmentId: s.letters.departmentId, department: s.departments.name, direction: s.letters.direction, status: s.letters.status, data: s.letters.data, workflowId: s.letters.workflowId, currentStep: s.letters.currentStep, revision: s.letters.revision, createdAt: s.letters.createdAt, updatedAt: s.letters.updatedAt, submittedAt: s.letters.submittedAt, approvedAt: s.letters.approvedAt, category: s.letterTemplates.category, templateName: s.letterTemplates.name }).from(s.letters).innerJoin(s.users, eq(s.letters.creatorId, s.users.id)).innerJoin(s.departments, eq(s.letters.departmentId, s.departments.id)).innerJoin(s.letterTemplates, eq(s.letters.templateId, s.letterTemplates.id)).where(user.roleId === "user" ? eq(s.letters.creatorId, user.id) : undefined).orderBy(desc(s.letters.updatedAt));
  const steps = await db.select({ workflowId: s.approvalSteps.workflowId, order: s.approvalSteps.order, name: s.approvalSteps.name, assigneeName: s.users.name }).from(s.approvalSteps).leftJoin(s.users, eq(s.approvalSteps.assigneeId, s.users.id));
  return rows.map(l => { const step = steps.find(st => st.workflowId === l.workflowId && st.order === l.currentStep); return { ...l, currentAssignee: step?.assigneeName || "Sesuai kewenangan", currentStepName: step?.name || "Selesai" }; });
}
export async function assertLetterAccess(id: string, user: User) { const [letter] = await db.select().from(s.letters).where(eq(s.letters.id, id)); if (!letter) throw new AppError("Surat tidak ditemukan.", 404); if (user.roleId === "user" && letter.creatorId !== user.id) throw new AppError("Anda tidak memiliki akses ke surat ini.", 403); return letter; }
export async function getWorkspace(user: User) {
  const [letters, templates, fields, roster, departments, workflows, steps, notifications, activities, settingRows] = await Promise.all([
    getLetters(user),
    db.select({ id: s.letterTemplates.id, name: s.letterTemplates.name, category: s.letterTemplates.category, description: s.letterTemplates.description, content: s.letterTemplates.content, fileName: s.letterTemplates.fileName, hasReference: sql<boolean>`${s.letterTemplates.referencePdf} is not null`, active: s.letterTemplates.active, workflowId: s.letterTemplates.workflowId, createdAt: s.letterTemplates.createdAt, updatedAt: s.letterTemplates.updatedAt }).from(s.letterTemplates).orderBy(asc(s.letterTemplates.createdAt)),
    db.select().from(s.templateFields).orderBy(asc(s.templateFields.order)),
    db.select({ id: s.users.id, name: s.users.name, email: s.users.email, roleId: s.users.roleId, departmentId: s.users.departmentId, department: s.departments.name, active: s.users.active, createdAt: s.users.createdAt }).from(s.users).innerJoin(s.departments, eq(s.users.departmentId, s.departments.id)).orderBy(asc(s.users.createdAt)),
    db.select().from(s.departments), db.select().from(s.approvalWorkflows),
    db.select({ id: s.approvalSteps.id, workflowId: s.approvalSteps.workflowId, name: s.approvalSteps.name, order: s.approvalSteps.order, roleId: s.approvalSteps.roleId, assigneeId: s.approvalSteps.assigneeId, assigneeName: s.users.name }).from(s.approvalSteps).leftJoin(s.users, eq(s.approvalSteps.assigneeId, s.users.id)).orderBy(asc(s.approvalSteps.order)),
    db.select().from(s.notifications).where(eq(s.notifications.userId, user.id)).orderBy(desc(s.notifications.createdAt)).limit(50),
    db.select({ id: s.auditLogs.id, userId: s.auditLogs.userId, userName: s.users.name, action: s.auditLogs.action, objectType: s.auditLogs.objectType, objectId: s.auditLogs.objectId, description: s.auditLogs.description, createdAt: s.auditLogs.createdAt }).from(s.auditLogs).leftJoin(s.users, eq(s.auditLogs.userId, s.users.id)).where(["super_admin", "admin"].includes(user.roleId) ? undefined : eq(s.auditLogs.userId, user.id)).orderBy(desc(s.auditLogs.createdAt)).limit(250),
    db.select().from(s.settings).where(eq(s.settings.key, "organization")),
  ]);
  return { user, letters, templates: templates.map(t => ({ ...t, fields: fields.filter(f => f.templateId === t.id) })), users: user.roleId === "user" ? roster.filter(u => u.id === user.id) : roster.map(u => ({ ...u, email: user.roleId === "super_admin" || u.id === user.id ? u.email : "" })), departments, workflows: workflows.map(w => ({ ...w, steps: steps.filter(st => st.workflowId === w.id) })), notifications, activities, settings: settingRows[0]?.value || {}, demo: process.env.DEMO_MODE !== "false", serverTime: new Date().toISOString() };
}
export async function letterDetail(id: string, user: User) {
  await assertLetterAccess(id, user); const letters = await getLetters(user); const letter = letters.find(l => l.id === id);
  const [approvals, revisions, attachments] = await Promise.all([
    db.select({ id: s.letterApprovals.id, action: s.letterApprovals.action, note: s.letterApprovals.note, actorName: s.users.name, createdAt: s.letterApprovals.createdAt, revision: s.letterApprovals.revision, stepName: s.approvalSteps.name }).from(s.letterApprovals).innerJoin(s.users, eq(s.letterApprovals.actorId, s.users.id)).leftJoin(s.approvalSteps, eq(s.letterApprovals.stepId, s.approvalSteps.id)).where(eq(s.letterApprovals.letterId, id)).orderBy(desc(s.letterApprovals.createdAt)),
    db.select({ id: s.letterRevisions.id, revision: s.letterRevisions.revision, note: s.letterRevisions.note, createdAt: s.letterRevisions.createdAt, actorName: s.users.name }).from(s.letterRevisions).innerJoin(s.users, eq(s.letterRevisions.actorId, s.users.id)).where(eq(s.letterRevisions.letterId, id)).orderBy(desc(s.letterRevisions.createdAt)),
    db.select({ id: s.letterAttachments.id, name: s.letterAttachments.name, size: s.letterAttachments.size, mimeType: s.letterAttachments.mimeType }).from(s.letterAttachments).where(eq(s.letterAttachments.letterId, id)),
  ]);
  const [archive] = await db.select({ snapshot: s.letterArchives.snapshot }).from(s.letterArchives).where(eq(s.letterArchives.letterId, id));
  const [template] = await db.select({ content: s.letterTemplates.content }).from(s.letterTemplates).where(eq(s.letterTemplates.id, letter!.templateId));
  return { letter, approvals, revisions, attachments, documentContent: typeof archive?.snapshot.content === "string" ? archive.snapshot.content : template?.content || "" };
}
