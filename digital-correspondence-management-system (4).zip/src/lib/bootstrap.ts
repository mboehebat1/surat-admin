import { db } from "@/db";
import * as s from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { hashPassword, AppError } from "./auth";
import { detectFields } from "./documents";
import { ROLE_LABELS } from "./types";

let ready: Promise<void> | undefined;
export function ensureBootstrap() { if (!ready) ready = initialize().catch(e => { ready = undefined; throw e; }); return ready; }
async function initialize() {
  await db.transaction(async tx => {
    await tx.execute(sql`select pg_advisory_xact_lock(7263101)`);
    const existing = await tx.select({ id: s.users.id }).from(s.users).limit(1); if (existing.length) return;
    const demo = process.env.DEMO_MODE !== "false";
    if (!demo && (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 12)) throw new AppError("Konfigurasikan ADMIN_EMAIL dan ADMIN_PASSWORD (minimal 12 karakter) untuk inisialisasi produksi.", 503);
    await tx.insert(s.roles).values(Object.entries(ROLE_LABELS).map(([id, name]) => ({ id, name }))).onConflictDoNothing();
    const access: Record<string, string[]> = { super_admin: ["users.manage", "templates.manage", "letters.manage", "letters.review", "letters.approve", "reports.read", "audit.read", "settings.manage"], admin: ["templates.manage", "letters.manage", "letters.review", "reports.read", "audit.read"], user: ["letters.create", "letters.own"], reviewer: ["letters.review", "letters.read"], approver: ["letters.approve", "letters.read", "reports.read"] };
    await tx.insert(s.permissions).values(Object.entries(access).flatMap(([roleId, codes]) => codes.map(code => ({ roleId, code })))).onConflictDoNothing();
    const deps = await tx.insert(s.departments).values([{ name: "Sekretariat", code: "SEK" }, { name: "Sumber Daya Manusia", code: "SDM" }, { name: "Keuangan", code: "KEU" }, { name: "Operasional", code: "OPS" }]).returning();
    const hash = hashPassword(demo ? "ESurat!2026" : process.env.ADMIN_PASSWORD!);
    const people = await tx.insert(s.users).values(demo ? [
      { name: "Ahmad Maulana", email: "admin@esurat.id", roleId: "super_admin", departmentId: deps[0].id, passwordHash: hash },
      { name: "Rina Pratiwi", email: "rina@esurat.id", roleId: "admin", departmentId: deps[0].id, passwordHash: hash },
      { name: "Budi Santoso", email: "budi@esurat.id", roleId: "reviewer", departmentId: deps[0].id, passwordHash: hash },
      { name: "Hendra Wijaya", email: "hendra@esurat.id", roleId: "approver", departmentId: deps[0].id, passwordHash: hash },
      { name: "Siti Nurhaliza", email: "siti@esurat.id", roleId: "user", departmentId: deps[1].id, passwordHash: hash },
      { name: "Dimas Saputra", email: "dimas@esurat.id", roleId: "user", departmentId: deps[3].id, passwordHash: hash },
    ] : [{ name: process.env.ADMIN_NAME || "Administrator", email: process.env.ADMIN_EMAIL!, roleId: "super_admin", departmentId: deps[0].id, passwordHash: hash }]).returning();
    const [wf] = await tx.insert(s.approvalWorkflows).values({ name: "Persetujuan Surat Standar", description: "Pemeriksaan administrasi, verifikasi kepala bagian, dan persetujuan pimpinan." }).returning();
    const steps = await tx.insert(s.approvalSteps).values([{ workflowId: wf.id, order: 0, name: "Pemeriksaan Administrasi", roleId: "admin", assigneeId: demo ? people[1].id : null }, { workflowId: wf.id, order: 1, name: "Verifikasi Kepala Bagian", roleId: "reviewer", assigneeId: demo ? people[2].id : null }, { workflowId: wf.id, order: 2, name: "Persetujuan Pimpinan", roleId: "approver", assigneeId: demo ? people[3].id : null }]).returning();
    const head = "NUSANTARA DIGITAL INDONESIA\nSekretariat Kantor Pusat\nJl. Jenderal Sudirman No. 28, Jakarta 10210\n\n";
    const base = "Nomor: {{nomor_surat}}\nTanggal: {{tanggal_surat}}\nLampiran: {{lampiran}}\nPerihal: {{perihal}}\n\nYth. {{nama_penerima}}\n{{jabatan_penerima}}\n{{alamat}}\n\nDengan hormat,\n\n{{isi_surat}}\n\nDemikian surat ini kami sampaikan. Atas perhatian dan kerja sama Bapak/Ibu, kami ucapkan terima kasih.\n\nHormat kami,\n{{jabatan_penandatangan}}\n\n\n{{nama_penandatangan}}";
    const templateNames = [{ name: "Surat Undangan", category: "Undangan", description: "Undangan rapat, kegiatan, dan acara resmi organisasi." }, { name: "Surat Tugas", category: "Penugasan", description: "Penugasan karyawan untuk kegiatan dan perjalanan dinas." }, { name: "Surat Keterangan", category: "Keterangan", description: "Keterangan kerja dan kebutuhan administrasi lainnya." }, { name: "Surat Permohonan", category: "Permohonan", description: "Pengajuan kebutuhan, izin, dan permohonan resmi." }, { name: "Surat Keputusan", category: "Keputusan", description: "Keputusan pimpinan dan penetapan kebijakan organisasi." }, { name: "Surat Edaran", category: "Edaran", description: "Informasi dan pemberitahuan resmi untuk seluruh unit." }];
    const templates = await tx.insert(s.letterTemplates).values(templateNames.map(t => ({ ...t, content: head + t.name.toUpperCase() + "\n\n" + base, workflowId: wf.id, createdBy: people[0].id }))).returning();
    await tx.insert(s.templateFields).values(templates.flatMap(t => detectFields(t.content).map(f => ({ ...f, templateId: t.id }))));
    await tx.insert(s.settings).values([{ key: "organization", value: { name: "Nusantara Digital Indonesia", office: "Kantor Pusat", address: "Jl. Jenderal Sudirman No. 28, Jakarta 10210", numberingFormat: "{nomor}/ES/{bulan}/{tahun}", demo } }, { key: "initialized", value: { at: new Date().toISOString(), demo } }]);
    if (!demo) { await tx.insert(s.auditLogs).values({ userId: people[0].id, action: "setup", objectType: "system", description: "Workspace E-SURAT berhasil diinisialisasi." }); return; }
    const now = new Date(); const year = now.getFullYear(); const month = now.getMonth();
    const subjects = ["Undangan Rapat Koordinasi Bulanan", "Penugasan Perjalanan Dinas ke Bandung", "Keterangan Aktif Bekerja", "Permohonan Pengadaan Perangkat Kerja", "Penetapan Tim Pelaksana Kegiatan", "Pemberitahuan Jadwal Operasional", "Undangan Evaluasi Kinerja Semester", "Penugasan Pelatihan Kompetensi", "Keterangan Penghasilan Karyawan", "Permohonan Izin Penggunaan Ruangan", "Penetapan Kebijakan Kerja Fleksibel", "Edaran Libur dan Cuti Bersama"];
    const counts = [14, 18, 21, 26, 32, 37]; let sequence = 0; const allLetters: typeof s.letters.$inferInsert[] = [];
    for (let mi = 0; mi < 6; mi++) for (let j = 0; j < counts[mi]; j++) {
      sequence++; const template = templates[j % templates.length]; const creator = people[j % 7 === 0 ? 0 : j % 2 ? 4 : 5];
      const created = new Date(year, month - 5 + mi, Math.min(25, j % 25 + 1), 8 + j % 8, j % 60); if (created > now) created.setTime(now.getTime() - (j + 1) * 3600000);
      const status = mi < 5 ? (j % 15 === 0 ? "rejected" : j % 4 === 0 ? "archived" : "completed") : j < 3 ? "pending_approval" : j < 6 ? "pending_review" : j < 8 ? "revision" : j < 11 ? "draft" : j < 13 ? "rejected" : j % 3 === 0 ? "approved" : "completed";
      const done = ["approved", "completed", "archived"].includes(status); const title = subjects[j % subjects.length];
      const stamp = mi === 5 && j < 8 ? new Date(now.getTime() - (j + 1) * 47 * 60000) : created;
      allLetters.push({ title, templateId: template.id, creatorId: creator.id, departmentId: creator.departmentId, direction: j % 5 < 2 ? "masuk" : "keluar", status, number: done ? `${String(sequence).padStart(3, "0")}/ES/${String(created.getMonth() + 1).padStart(2, "0")}/${created.getFullYear()}` : null, workflowId: wf.id, currentStep: status === "pending_approval" ? 2 : 0, createdAt: stamp, updatedAt: stamp, submittedAt: status === "draft" ? null : stamp, approvedAt: done ? new Date(stamp.getTime() + 6 * 3600000) : null, data: { perihal: title, tanggal_surat: stamp.toISOString().slice(0, 10), nama_penerima: "Kepala Divisi Operasional", jabatan_penerima: "Kepala Divisi", alamat: "Di tempat", isi_surat: `Sehubungan dengan ${title.toLowerCase()}, bersama ini kami menyampaikan permohonan dan informasi untuk ditindaklanjuti sesuai dengan ketentuan yang berlaku.\n\nKegiatan ini merupakan bagian dari program kerja organisasi untuk meningkatkan kualitas pelayanan dan koordinasi antardepartemen. Kami mengharapkan partisipasi serta dukungan dari seluruh pihak terkait.`, nama_penandatangan: "Hendra Wijaya", jabatan_penandatangan: "Direktur Utama", lampiran: "-" } });
    }
    const inserted = await tx.insert(s.letters).values(allLetters).returning();
    const final = inserted.filter(l => ["approved", "completed", "archived"].includes(l.status));
    await tx.insert(s.letterArchives).values(final.map(l => ({ letterId: l.id, category: templates.find(t => t.id === l.templateId)!.category, year: new Date(l.createdAt).getFullYear(), snapshot: { title: l.title, number: l.number, data: l.data, content: templates.find(t => t.id === l.templateId)!.content }, archivedBy: people[3].id, archivedAt: l.approvedAt! })));
    await tx.insert(s.letterApprovals).values(final.flatMap(l => steps.map((step, i) => ({ letterId: l.id, stepId: step.id, actorId: people[i + 1].id, action: "approve", note: i === 2 ? "Disetujui sesuai kewenangan. Silakan didistribusikan." : "Dokumen telah diperiksa dan lengkap.", createdAt: new Date(l.updatedAt.getTime() + (i + 1) * 3600000) }))));
    const recent = inserted.sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime()).slice(0, 12);
    await tx.insert(s.auditLogs).values(recent.map((l, i) => ({ userId: l.creatorId, action: l.status === "revision" ? "revision" : l.status === "approved" || l.status === "completed" ? "approve" : l.status === "draft" ? "create" : "submit", objectType: "letter", objectId: l.id, description: `${l.status === "revision" ? "Surat dikembalikan untuk revisi" : l.status === "draft" ? "Menyimpan draft surat" : l.status === "approved" || l.status === "completed" ? "Surat berhasil disetujui" : "Mengajukan surat"}: ${l.title}`, createdAt: new Date(now.getTime() - (i + 1) * 23 * 60000) })));
    await tx.insert(s.notifications).values(recent.slice(0, 4).map(l => ({ userId: people[0].id, letterId: l.id, title: l.status === "revision" ? "Surat membutuhkan revisi" : "Surat menunggu tindakan", message: l.title, createdAt: l.updatedAt })));
    await tx.insert(s.numberingSequences).values({ id: `ES-${year}`, year, lastNumber: sequence });
  });
}
