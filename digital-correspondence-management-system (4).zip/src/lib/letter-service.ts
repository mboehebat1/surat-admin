import { db } from "@/db";
import * as s from "@/db/schema";
import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { AppError } from "./auth";
import type { User } from "./types";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type LetterInput = { title: string; templateId: string; direction: string; data: Record<string, string>; intent: string };
export async function audit(userId: string, action: string, objectType: string, objectId: string | null, description: string, tx: Tx | typeof db = db) { await tx.insert(s.auditLogs).values({ userId, action, objectType, objectId, description }); }
async function notify(tx: Tx, userId: string, letterId: string, title: string, message: string) { await tx.insert(s.notifications).values({ userId, letterId, title, message }); }
async function notifyStep(tx: Tx, letterId: string, workflowId: string, order: number, title: string) { const [step] = await tx.select().from(s.approvalSteps).where(and(eq(s.approvalSteps.workflowId, workflowId), eq(s.approvalSteps.order, order))); if (!step) return; const recipients = await tx.select({ id: s.users.id }).from(s.users).where(and(eq(s.users.active, true), eq(s.users.roleId, step.roleId), step.assigneeId ? eq(s.users.id, step.assigneeId) : undefined)); for (const u of recipients) await notify(tx, u.id, letterId, "Surat membutuhkan tindakan", `${title} • ${step.name}`); }
function validateData(fields: typeof s.templateFields.$inferSelect[], data: Record<string, string>) { const missing = fields.filter(f => f.required && f.key !== "nomor_surat" && !data[f.key]?.trim()); if (missing.length) throw new AppError(`Lengkapi field: ${missing.map(f => f.label).join(", ")}.`); }
export async function createLetter(input: LetterInput, user: User) {
  return db.transaction(async tx => {
    const [template] = await tx.select().from(s.letterTemplates).where(eq(s.letterTemplates.id, input.templateId)); if (!template || !template.active) throw new AppError("Template tidak tersedia atau tidak aktif.");
    if (!template.workflowId && input.intent === "submit") throw new AppError("Template belum memiliki alur persetujuan.");
    const fields = await tx.select().from(s.templateFields).where(eq(s.templateFields.templateId, template.id)); if (input.intent === "submit") validateData(fields, input.data);
    const safeData = Object.fromEntries(fields.filter(f => f.key !== "nomor_surat").map(f => [f.key, input.data[f.key] || ""]));
    const [letter] = await tx.insert(s.letters).values({ title: input.title, templateId: template.id, creatorId: user.id, departmentId: user.departmentId, direction: input.direction, data: safeData, workflowId: template.workflowId, status: input.intent === "submit" ? "pending_review" : "draft", submittedAt: input.intent === "submit" ? new Date() : null }).returning();
    await audit(user.id, "create", "letter", letter.id, `Membuat ${input.intent === "submit" ? "dan mengajukan" : "draft"} surat: ${letter.title}`, tx);
    if (input.intent === "submit") { await tx.insert(s.letterApprovals).values({ letterId: letter.id, actorId: user.id, action: "submit", note: "Surat diajukan untuk pemeriksaan." }); await notify(tx, user.id, letter.id, "Pengajuan surat berhasil", letter.title); await notifyStep(tx, letter.id, template.workflowId!, 0, letter.title); }
    return letter;
  });
}
export async function updateLetter(id: string, input: LetterInput, user: User) {
  return db.transaction(async tx => {
    const [letter] = await tx.select().from(s.letters).where(eq(s.letters.id, id)).for("update"); if (!letter) throw new AppError("Surat tidak ditemukan.", 404);
    if (letter.creatorId !== user.id) throw new AppError("Hanya pembuat yang dapat mengubah surat.", 403);
    if (!["draft", "revision"].includes(letter.status)) throw new AppError("Surat sedang diproses dan tidak dapat diubah.", 409);
    if (input.templateId !== letter.templateId) throw new AppError("Template draft tidak dapat diubah. Buat surat baru untuk mengganti template.");
    const fields = await tx.select().from(s.templateFields).where(eq(s.templateFields.templateId, letter.templateId)); if (input.intent === "submit") validateData(fields, input.data);
    const revision = letter.revision + (input.intent === "submit" && letter.status === "revision" ? 1 : 0);
    const [updated] = await tx.update(s.letters).set({ title: input.title, data: Object.fromEntries(fields.filter(f => f.key !== "nomor_surat").map(f => [f.key, input.data[f.key] || ""])), direction: input.direction, updatedAt: new Date(), ...(input.intent === "submit" ? { status: "pending_review", submittedAt: new Date(), currentStep: 0, revision } : {}) }).where(eq(s.letters.id, id)).returning();
    await audit(user.id, input.intent === "submit" ? "submit" : "edit", "letter", id, `${input.intent === "submit" ? "Mengajukan" : "Memperbarui"} surat: ${letter.title}`, tx);
    if (input.intent === "submit") { if (!letter.workflowId) throw new AppError("Alur persetujuan belum dikonfigurasi."); await tx.insert(s.letterApprovals).values({ letterId: id, actorId: user.id, action: "submit", revision, note: letter.status === "revision" ? "Perbaikan telah diselesaikan dan diajukan kembali." : "Surat diajukan untuk pemeriksaan." }); await notify(tx, user.id, id, "Pengajuan surat berhasil", updated.title); await notifyStep(tx, id, letter.workflowId, 0, updated.title); }
    return updated;
  });
}
export async function actOnLetter(id: string, action: string, note: string, user: User, expectedStep?: number) {
  return db.transaction(async tx => {
    const [letter] = await tx.select().from(s.letters).where(eq(s.letters.id, id)).for("update"); if (!letter) throw new AppError("Surat tidak ditemukan.", 404);
    if (user.roleId === "user" && letter.creatorId !== user.id) throw new AppError("Anda tidak memiliki akses.", 403);
    if (action === "duplicate") { const [copy] = await tx.insert(s.letters).values({ title: `${letter.title} (Salinan)`, templateId: letter.templateId, creatorId: user.id, departmentId: user.departmentId, direction: letter.direction, data: { ...letter.data, tanggal_surat: new Date().toISOString().slice(0, 10) }, workflowId: letter.workflowId }).returning(); await audit(user.id, "duplicate", "letter", copy.id, `Menduplikasi surat: ${letter.title}`, tx); return copy; }
    if (["archive", "complete", "distribute"].includes(action)) {
      if (!["super_admin", "admin"].includes(user.roleId)) throw new AppError("Hanya administrator persuratan yang dapat menyelesaikan atau mengarsipkan surat.", 403);
      if (!["approved", "completed", "archived"].includes(letter.status)) throw new AppError("Hanya surat yang disetujui dapat didistribusikan atau diarsipkan.", 409);
      if (letter.status === "archived" && action !== "archive") throw new AppError("Surat yang telah diarsipkan tidak dapat dikembalikan ke proses distribusi.", 409);
      if (action === "distribute" && note.trim().length < 3) throw new AppError("Masukkan tujuan distribusi surat.");
      const status = action === "archive" ? "archived" : "completed"; const [updated] = await tx.update(s.letters).set({ status, updatedAt: new Date() }).where(eq(s.letters.id, id)).returning();
      const [template] = await tx.select().from(s.letterTemplates).where(eq(s.letterTemplates.id, letter.templateId));
      await tx.insert(s.letterArchives).values({ letterId: id, category: template.category, year: new Date().getFullYear(), snapshot: { title: letter.title, number: letter.number, data: letter.data, content: template.content, fileData: template.fileData }, archivedBy: user.id }).onConflictDoNothing();
      await audit(user.id, action, "letter", id, `${action === "archive" ? "Mengarsipkan" : action === "distribute" ? `Mendistribusikan surat ke ${note}:` : "Menyelesaikan"} surat: ${letter.title}`, tx); await notify(tx, letter.creatorId, id, action === "distribute" ? "Surat telah didistribusikan" : "Surat selesai diproses", `${letter.title}${note ? ` • ${note}` : ""}`); return updated;
    }
    if (!["pending_review", "reviewing", "pending_approval", "submitted"].includes(letter.status)) throw new AppError("Status surat telah berubah. Muat ulang data sebelum bertindak.", 409);
    if (letter.creatorId === user.id) throw new AppError("Anda tidak dapat memeriksa atau menyetujui surat yang Anda buat sendiri.", 403);
    const steps = await tx.select().from(s.approvalSteps).where(eq(s.approvalSteps.workflowId, letter.workflowId!)).orderBy(asc(s.approvalSteps.order)); const step = steps.find(st => st.order === letter.currentStep);
    if (!step) throw new AppError("Tahapan persetujuan tidak ditemukan.");
    if (user.roleId !== "super_admin" && (step.roleId !== user.roleId || (step.assigneeId && step.assigneeId !== user.id))) throw new AppError("Surat ini bukan kewenangan Anda pada tahap saat ini.", 403);
    if (expectedStep !== letter.currentStep) throw new AppError("Tahapan surat telah berubah. Muat ulang detail surat sebelum bertindak.", 409);
    if (action === "start_review" && letter.status !== "pending_review") throw new AppError("Pemeriksaan sudah dimulai atau surat bukan pada tahap pemeriksaan.", 409);
    if (["revision", "reject"].includes(action) && note.trim().length < 5) throw new AppError("Tuliskan alasan atau catatan minimal 5 karakter.");
    const patch: Partial<typeof s.letters.$inferInsert> = { updatedAt: new Date() }; let message = "";
    if (action === "start_review") { patch.status = "reviewing"; message = "Surat sedang diperiksa"; }
    else if (action === "revision") { patch.status = "revision"; patch.currentStep = 0; message = "Surat membutuhkan revisi"; await tx.insert(s.letterRevisions).values({ letterId: id, actorId: user.id, revision: letter.revision, data: letter.data, note }); }
    else if (action === "reject") { patch.status = "rejected"; message = "Pengajuan surat ditolak"; }
    else if (action === "approve") {
      const next = steps.find(st => st.order > step.order);
      if (next) { patch.currentStep = next.order; patch.status = next.roleId === "approver" ? "pending_approval" : "pending_review"; message = `Surat diteruskan ke ${next.name}`; await notifyStep(tx, id, letter.workflowId!, next.order, letter.title); }
      else {
        const now = new Date(); const year = now.getFullYear(); const [sequence] = await tx.insert(s.numberingSequences).values({ id: `ES-${year}`, year, lastNumber: 1 }).onConflictDoUpdate({ target: s.numberingSequences.id, set: { lastNumber: sql`${s.numberingSequences.lastNumber} + 1` } }).returning();
        const [setting] = await tx.select().from(s.settings).where(eq(s.settings.key, "organization")); const format = String(setting?.value.numberingFormat || sequence.format);
        patch.number = format.replaceAll("{nomor}", String(sequence.lastNumber).padStart(3, "0")).replaceAll("{bulan}", String(now.getMonth() + 1).padStart(2, "0")).replaceAll("{tahun}", String(year)); patch.status = "approved"; patch.approvedAt = now; message = "Surat disetujui";
        const [template] = await tx.select().from(s.letterTemplates).where(eq(s.letterTemplates.id, letter.templateId));
        await tx.insert(s.letterArchives).values({ letterId: id, category: template.category, year, snapshot: { title: letter.title, number: patch.number, data: letter.data, content: template.content, fileData: template.fileData, approval: { actor: user.name, at: now.toISOString(), note } }, archivedBy: user.id }).onConflictDoNothing();
      }
    } else throw new AppError("Tindakan tidak dikenali.");
    const [updated] = await tx.update(s.letters).set(patch).where(eq(s.letters.id, id)).returning();
    await tx.insert(s.letterApprovals).values({ letterId: id, stepId: step.id, actorId: user.id, action, note, revision: letter.revision }); await audit(user.id, action, "letter", id, `${message}: ${letter.title}${note ? ` • ${note}` : ""}`, tx); await notify(tx, letter.creatorId, id, message, letter.title); return updated;
  });
}
export async function removeDraft(id: string, user: User) { await db.transaction(async tx => { const [letter] = await tx.select().from(s.letters).where(eq(s.letters.id, id)).for("update"); if (!letter) throw new AppError("Surat tidak ditemukan.", 404); if (letter.creatorId !== user.id || letter.status !== "draft") throw new AppError("Hanya draft milik sendiri yang dapat dihapus.", 403); const history = await tx.select({ id: s.letterApprovals.id }).from(s.letterApprovals).where(eq(s.letterApprovals.letterId, id)).limit(1); if (history.length) throw new AppError("Surat dengan riwayat persetujuan tidak dapat dihapus."); await tx.delete(s.notifications).where(eq(s.notifications.letterId, id)); await tx.delete(s.letters).where(eq(s.letters.id, id)); await audit(user.id, "delete", "letter", id, `Menghapus draft: ${letter.title}`, tx); }); }
