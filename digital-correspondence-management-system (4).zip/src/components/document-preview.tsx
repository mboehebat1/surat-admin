"use client";
export function DocumentPreview({ content, data = {}, number, className = "" }: { content: string; data?: Record<string, string>; number?: string | null; className?: string }) {
  const values: Record<string, string> = { ...data, ...(number ? { nomor_surat: number } : {}) }; const filled = content.replace(/\{\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\}\}/g, (match, key: string) => values[key]?.trim() || match);
  return <div className={`document-paper ${className}`}><div className="document-watermark">E-SURAT</div>{filled.split("\n").map((line, i) => <div key={i} className={`document-line ${i < 3 || (i === 4 && line === line.toUpperCase()) ? "document-center" : ""} ${i === 0 ? "document-brand" : ""} ${i === 2 ? "document-letterhead-bottom" : ""}`}>{line ? line.split(/(\{\{[^}]+\}\})/g).map((part, j) => part.startsWith("{{") ? <mark key={j}>{part === "{{nomor_surat}}" ? "Nomor otomatis setelah persetujuan" : part}</mark> : <span key={j}>{part}</span>) : <br />}</div>)}</div>;
}
