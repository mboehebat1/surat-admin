"use client";
import { createContext, useContext } from "react";
import type { Letter, Template, User, Workspace } from "@/lib/types";
export type WorkspaceContextValue = { data: Workspace; refresh: () => Promise<void>; notify: (message: string, type?: "success" | "error" | "info") => void; openLetter: (id: string) => void; openComposer: (letter?: Letter, templateId?: string) => void; openTemplate: (template?: Template) => void; openUser: (user?: User) => void; search: string; setSearch: (value: string) => void };
export const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);
export function useWorkspace() { const value = useContext(WorkspaceContext); if (!value) throw new Error("Workspace tidak tersedia."); return value; }
