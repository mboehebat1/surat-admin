import { pgTable, uuid, varchar, text, timestamp, integer, boolean, jsonb, uniqueIndex, index } from "drizzle-orm/pg-core";

export const departments = pgTable("departments", {
  id: uuid("id").defaultRandom().primaryKey(), name: varchar("name", { length: 120 }).notNull(), code: varchar("code", { length: 20 }).notNull().unique(),
});
export const roles = pgTable("roles", {
  id: varchar("id", { length: 30 }).primaryKey(), name: varchar("name", { length: 80 }).notNull(), description: text("description"),
});
export const permissions = pgTable("permissions", {
  id: uuid("id").defaultRandom().primaryKey(), roleId: varchar("role_id", { length: 30 }).notNull().references(() => roles.id, { onDelete: "cascade" }), code: varchar("code", { length: 80 }).notNull(),
}, (t) => [uniqueIndex("role_permission_unique").on(t.roleId, t.code)]);
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(), name: varchar("name", { length: 120 }).notNull(), email: varchar("email", { length: 180 }).notNull().unique(), passwordHash: text("password_hash").notNull(),
  roleId: varchar("role_id", { length: 30 }).notNull().references(() => roles.id), departmentId: uuid("department_id").notNull().references(() => departments.id), active: boolean("active").default(true).notNull(), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const sessions = pgTable("sessions", {
  tokenHash: varchar("token_hash", { length: 64 }).primaryKey(), userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }), expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});
export const approvalWorkflows = pgTable("approval_workflows", {
  id: uuid("id").defaultRandom().primaryKey(), name: varchar("name", { length: 120 }).notNull(), description: text("description"), active: boolean("active").default(true).notNull(),
});
export const approvalSteps = pgTable("approval_steps", {
  id: uuid("id").defaultRandom().primaryKey(), workflowId: uuid("workflow_id").notNull().references(() => approvalWorkflows.id, { onDelete: "cascade" }), order: integer("step_order").notNull(), name: varchar("name", { length: 100 }).notNull(), roleId: varchar("role_id", { length: 30 }).notNull().references(() => roles.id), assigneeId: uuid("assignee_id").references(() => users.id),
}, (t) => [uniqueIndex("workflow_step_order").on(t.workflowId, t.order)]);
export const letterTemplates = pgTable("letter_templates", {
  id: uuid("id").defaultRandom().primaryKey(), name: varchar("name", { length: 160 }).notNull(), category: varchar("category", { length: 80 }).notNull(), description: text("description").default(""), content: text("content").notNull(), fileData: text("file_data"), fileName: text("file_name"), referencePdf: text("reference_pdf"),
  workflowId: uuid("workflow_id").references(() => approvalWorkflows.id), active: boolean("active").default(true).notNull(), createdBy: uuid("created_by").references(() => users.id), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(), updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
export const templateFields = pgTable("template_fields", {
  id: uuid("id").defaultRandom().primaryKey(), templateId: uuid("template_id").notNull().references(() => letterTemplates.id, { onDelete: "cascade" }), key: varchar("key", { length: 80 }).notNull(), label: varchar("label", { length: 120 }).notNull(), type: varchar("type", { length: 20 }).default("text").notNull(), required: boolean("required").default(true).notNull(), order: integer("field_order").default(0).notNull(),
}, (t) => [uniqueIndex("template_field_key").on(t.templateId, t.key)]);
export const letters = pgTable("letters", {
  id: uuid("id").defaultRandom().primaryKey(), title: varchar("title", { length: 220 }).notNull(), number: varchar("number", { length: 100 }).unique(), templateId: uuid("template_id").notNull().references(() => letterTemplates.id), creatorId: uuid("creator_id").notNull().references(() => users.id), departmentId: uuid("department_id").notNull().references(() => departments.id),
  direction: varchar("direction", { length: 12 }).default("keluar").notNull(), status: varchar("status", { length: 40 }).default("draft").notNull(), data: jsonb("data").$type<Record<string, string>>().notNull().default({}), workflowId: uuid("workflow_id").references(() => approvalWorkflows.id), currentStep: integer("current_step").default(0).notNull(), revision: integer("revision").default(1).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(), updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(), submittedAt: timestamp("submitted_at", { withTimezone: true }), approvedAt: timestamp("approved_at", { withTimezone: true }),
}, (t) => [index("letter_status_index").on(t.status), index("letter_creator_index").on(t.creatorId)]);
export const letterAttachments = pgTable("letter_attachments", {
  id: uuid("id").defaultRandom().primaryKey(), letterId: uuid("letter_id").notNull().references(() => letters.id, { onDelete: "cascade" }), name: varchar("name", { length: 200 }).notNull(), mimeType: varchar("mime_type", { length: 120 }).notNull(), size: integer("size").notNull(), data: text("data").notNull(), uploadedBy: uuid("uploaded_by").notNull().references(() => users.id), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const letterApprovals = pgTable("letter_approvals", {
  id: uuid("id").defaultRandom().primaryKey(), letterId: uuid("letter_id").notNull().references(() => letters.id), stepId: uuid("step_id").references(() => approvalSteps.id), actorId: uuid("actor_id").notNull().references(() => users.id), action: varchar("action", { length: 30 }).notNull(), note: text("note"), revision: integer("revision").default(1).notNull(), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const letterRevisions = pgTable("letter_revisions", {
  id: uuid("id").defaultRandom().primaryKey(), letterId: uuid("letter_id").notNull().references(() => letters.id), actorId: uuid("actor_id").notNull().references(() => users.id), revision: integer("revision").notNull(), data: jsonb("data").$type<Record<string, string>>().notNull(), note: text("note"), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(), userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }), letterId: uuid("letter_id").references(() => letters.id), title: varchar("title", { length: 200 }).notNull(), message: text("message").notNull(), read: boolean("read").default(false).notNull(), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(), userId: uuid("user_id").references(() => users.id), action: varchar("action", { length: 100 }).notNull(), objectType: varchar("object_type", { length: 50 }).notNull(), objectId: text("object_id"), description: text("description").notNull(), metadata: jsonb("metadata").$type<Record<string, unknown>>(), createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
export const letterArchives = pgTable("letter_archives", {
  id: uuid("id").defaultRandom().primaryKey(), letterId: uuid("letter_id").notNull().references(() => letters.id).unique(), category: varchar("category", { length: 80 }).notNull(), year: integer("year").notNull(), snapshot: jsonb("snapshot").$type<Record<string, unknown>>().notNull(), archivedBy: uuid("archived_by").notNull().references(() => users.id), archivedAt: timestamp("archived_at", { withTimezone: true }).defaultNow().notNull(),
});
export const numberingSequences = pgTable("numbering_sequences", {
  id: varchar("id", { length: 30 }).primaryKey(), year: integer("year").notNull(), lastNumber: integer("last_number").default(0).notNull(), format: varchar("format", { length: 100 }).default("{nomor}/ES/{bulan}/{tahun}").notNull(),
});
export const settings = pgTable("settings", { key: varchar("key", { length: 80 }).primaryKey(), value: jsonb("value").$type<Record<string, unknown>>().notNull() });
