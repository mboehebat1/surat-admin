import { notFound } from "next/navigation";
import { WorkspaceApp } from "@/components/workspace";
export const dynamic = "force-dynamic";
export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) { const { section } = await params; if (!["dashboard", "surat", "persetujuan", "template", "monitoring", "arsip", "laporan", "pengguna", "audit", "pengaturan"].includes(section)) notFound(); return <WorkspaceApp />; }
