import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
export const metadata: Metadata = { title: "E-SURAT — Sistem Persuratan Digital", description: "Satu workspace untuk membuat, memeriksa, menyetujui, dan mengarsipkan surat secara digital.", icons: { icon: "/icon.svg" } };
export default function RootLayout({ children }: { children: ReactNode }) { return <html lang="id"><body>{children}</body></html>; }
