import { WorkspaceApp } from "@/components/workspace";
export const dynamic = "force-dynamic";
export default function HomePage() { return <WorkspaceApp />; }
