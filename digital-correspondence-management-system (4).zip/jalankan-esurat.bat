@echo off
setlocal EnableExtensions DisableDelayedExpansion
title E-SURAT - Peluncur Windows
chcp 65001 >nul 2>&1

echo.
echo ============================================================
echo   E-SURAT - Sistem Persuratan Digital
echo   Peluncur lokal Windows
echo ============================================================
echo.

set "ESURAT_ROOT=%~dp0"
if exist "%ESURAT_ROOT%package.json" if exist "%ESURAT_ROOT%scripts\windows-launcher.mjs" goto project_found

for %%I in ("%~dp0..\..") do set "ESURAT_ROOT=%%~fI\"
if exist "%ESURAT_ROOT%package.json" if exist "%ESURAT_ROOT%scripts\windows-launcher.mjs" goto project_found

echo Letakkan file BAT ini di folder proyek, sejajar package.json.
echo Atau masukkan lokasi folder proyek E-SURAT di bawah ini.
echo.
set "ESURAT_ROOT="
set /p "ESURAT_ROOT=Lokasi folder proyek: "
if not defined ESURAT_ROOT goto project_missing
set "ESURAT_ROOT=%ESURAT_ROOT:"=%"
for %%I in ("%ESURAT_ROOT%") do set "ESURAT_ROOT=%%~fI\"
if not exist "%ESURAT_ROOT%package.json" goto project_missing
if not exist "%ESURAT_ROOT%scripts\windows-launcher.mjs" goto project_missing

:project_found
where node.exe >nul 2>&1
if errorlevel 1 goto node_missing
where npm.cmd >nul 2>&1
if errorlevel 1 goto npm_missing

pushd "%ESURAT_ROOT%"
if errorlevel 1 goto project_missing
node "scripts\windows-launcher.mjs" %*
set "ESURAT_EXIT=%ERRORLEVEL%"
popd
if "%ESURAT_EXIT%"=="0" goto done

echo.
echo Peluncur berhenti. Baca petunjuk kesalahan di atas.
echo Panduan lengkap: README-WINDOWS.md
echo.
pause
goto done

:project_missing
echo.
echo [GAGAL] Folder proyek E-SURAT lengkap tidak ditemukan.
echo File BAT saja bukan aplikasi. Ekstrak seluruh proyek terlebih dahulu.
echo Pastikan package.json dan scripts\windows-launcher.mjs tersedia.
set "ESURAT_EXIT=1"
pause
goto done

:node_missing
echo [GAGAL] Node.js belum terpasang atau belum tersedia di PATH.
echo Pasang Node.js 22 LTS atau lebih baru dari https://nodejs.org/
echo Setelah memasang Node.js, tutup terminal lalu jalankan BAT kembali.
set "ESURAT_EXIT=1"
pause
goto done

:npm_missing
echo [GAGAL] npm tidak ditemukan. Perbaiki instalasi Node.js terlebih dahulu.
set "ESURAT_EXIT=1"
pause

:done
endlocal & exit /b %ESURAT_EXIT%
